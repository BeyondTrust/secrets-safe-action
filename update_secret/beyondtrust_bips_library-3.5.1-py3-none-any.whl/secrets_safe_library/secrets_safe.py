"""SecretsSafe Module, all the logic to retrieve secrets from PS API"""

import logging
from urllib.parse import urlencode

import requests

from secrets_safe_library import exceptions, utils
from secrets_safe_library.authentication import Authentication
from secrets_safe_library.constants.endpoints import (
    POST_SECRETS_SAFE_FOLDERS_FOLDERID,
    POST_SECRETS_SAFE_FOLDERS_FOLDERID_FILE,
    POST_SECRETS_SAFE_FOLDERS_FOLDERID_TEXT,
    PUT_SECRETS_SAFE_SECRETS_SECRETID,
    PUT_SECRETS_SAFE_SECRETS_SECRETID_FILE,
    PUT_SECRETS_SAFE_SECRETS_SECRETID_TEXT,
)
from secrets_safe_library.core import APIObject
from secrets_safe_library.mapping.secrets import fields as secrets_fields
from secrets_safe_library.validators.secrets import SecretsValidator


class SecretsSafe(APIObject, SecretsValidator):
    _separator: str = None
    _decrypt: bool = None

    def __init__(
        self,
        authentication: Authentication,
        logger: logging.Logger = None,
        separator: str = "/",
        decrypt: bool = None,
    ):
        """
        Initialize a SecretsSafe client used to interact with the Secrets Safe API.
        Args:
            authentication (Authentication): Authentication handler used to make
                authorized requests to the API.
            logger (logging.Logger, optional): Logger instance to use for emitting
                diagnostic messages. If None, the default logger behavior from
                the base class is used.
            separator (str, optional): Path separator used when building and
                parsing secret paths (for example, between folder and secret
                name). Must resolve to a single non-whitespace character after
                stripping. Defaults to "/".
            decrypt (bool, optional): Whether to request decrypted secret values
                when retrieving them. If True, decrypted values are requested;
                if False, encrypted values may be returned depending on server
                support. If None, the server-side default behavior is used.
        """
        super().__init__(authentication, logger, endpoint="/secrets-safe/secrets")

        if len(separator.strip()) != 1:
            raise exceptions.LookupError(f"Invalid separator: {separator}")

        self._separator = separator
        self._decrypt = decrypt

        # Initialize the SecretsValidator parent class
        SecretsValidator.__init__(self)

    def set_decrypt(self, decrypt: bool) -> None:
        """
        Set the decrypt attribute
        Arguments:
        - True: request decrypted secret values.
        - False: request encrypted secret values, if supported by the server.
        - None: use the server-side default behavior.
        """

        self._decrypt = decrypt

    def get_secret(self, path: str) -> str:
        """
        Get secret by path
        Arguments:
            path (str): secret path
        Returns:
            Retrieved secret string

        """

        utils.print_log(
            self._logger,
            "Running get_secret method in SecretsSafe class",
            logging.DEBUG,
        )
        secrets_dict = self.secrets_by_path_flow(paths=[path])
        return secrets_dict[path]

    def get_secret_with_metadata(self, path: str) -> dict:
        """
        Get secret by path with metadata
        Arguments:
            path (str): secret path
        Returns:
           Retrieved secret in dict format
        """

        utils.print_log(
            self._logger,
            "Running get_secret method in SecretsSafe class",
            logging.DEBUG,
        )
        secrets_dict = self.secrets_by_path_flow(paths=[path], get_metadata=True)
        return secrets_dict

    def get_secrets(self, paths: list) -> dict:
        """
        Get secrets by paths
        Arguments:
            paths (list): list of secret paths
        Returns:
            Retrieved secret in dict format
        """

        utils.print_log(
            self._logger,
            "Running get_secrets method in SecretsSafe class",
            logging.INFO,
        )
        secrets_dict = self.secrets_by_path_flow(paths=paths)
        return secrets_dict

    def get_secrets_with_metadata(self, paths: list):
        """
        Get secrets by paths with metadata
        Arguments:
            paths (list): list of secret paths
        Returns:
            Retrieved secret in dict format
        """

        utils.print_log(
            self._logger,
            "Running get_secrets method in SecretsSafe class",
            logging.INFO,
        )
        secrets_dict = self.secrets_by_path_flow(paths=paths, get_metadata=True)
        return secrets_dict

    def get_all_secrets_by_folder_path(self, folder_path: str) -> dict:
        """
        Get all secrets by folder path
        Arguments:
            folder_path (str): folder path
        Returns:
            Response (Dict)
        """

        response = {}
        secret_response = self.get_secret_by_path(
            folder_path, None, self._separator, send_title=False
        )
        for secret in secret_response.json():
            secret_path = f"{secret['FolderPath']}/{secret['Title']}"
            response[f"{secret_path}-metadata"] = secret
            if secret["SecretType"] == "File":
                response[secret_path] = self.get_file_secret_data(secret["Id"])
            else:
                response[secret_path] = secret["Password"]
        return response

    def get_file_secret_data(self, secret_id) -> str:
        """
        Gets secret file as an attachment based on secretId.

        API: GET Secrets-Safe/Secrets/{secretId:guid}/file/download

        Args:
            secret_id (str): The secret id (GUID).

        Returns:
            file secret content (str).
        """

        utils.print_log(self._logger, "Getting secret by file", logging.DEBUG)
        try:
            file_response = self._get_file_by_id_req(secret_id)
        except exceptions.LookupError as e:
            raise exceptions.LookupError(f"Error getting file by id: {e}")

        return file_response.text

    def secrets_by_path_flow(self, paths: list, get_metadata: bool = False) -> dict:
        """
        Secrets by path flow
        Arguments:
            paths (list): list of secret paths
            get_metadata (bool): whether to get secret metadata or not.
        Returns:
            Response (Dict)
        """

        response = {}
        for path in paths:

            if not path:
                continue

            data = path.split(self._separator)

            if len(data) < 2:
                raise exceptions.LookupError(
                    f"Invalid secret path: {path}, check your path and title separator,"
                    f" separator must be: {self._separator}"
                )

            folder_path = data[:-1]
            title = data[-1]

            try:
                secret_response = self.get_secret_by_path(
                    path=self._separator.join(folder_path),
                    title=title,
                    separator=self._separator,
                )
            except exceptions.LookupError as e:
                raise exceptions.LookupError(f"Error getting secret by path: {e}")

            secret = secret_response.json()
            if secret:
                if get_metadata:
                    response[f"{path}-metadata"] = secret[0]

                if secret[0]["SecretType"] == "File":
                    response[path] = self.get_file_secret_data(secret[0]["Id"])
                else:
                    response[path] = secret[0]["Password"]

                utils.print_log(
                    self._logger, "A secret was successfully retrieved", logging.INFO
                )
            else:
                raise exceptions.LookupError(f"{path}, Secret was not found")

        return response

    def get_secret_by_path(
        self, path: str, title: str, separator: str, send_title: bool = True
    ) -> requests.Response:
        """
        Get secrets by path and title.
        Arguments:
            path (str): The path where the secret is stored.
            title (str): The title used to identify the secret.
            separator (str): The separator used in the secret storage format.
            send_title (bool, optional): Flag to determine if the title should be
                included in the request. Defaults to True.
        Returns:
            requests.Response: A response object containing the secret.

        Raises:
            exceptions.OptionsError: If any of the schema rules are not valid.
        """

        path_depth = path.count(separator) + 1
        attributes = {"path": path, "title": title, "path_depth": path_depth}

        # Use the new SecretsValidator instead of the old Cerberus validator
        self.validate(attributes, operation="get_secret_by_path")

        query_params = {"path": path, "separator": separator}

        if self._decrypt is not None:
            query_params["decrypt"] = str(self._decrypt).lower()

        if self._authentication._api_version:
            query_params["version"] = self._authentication._api_version

        if send_title:
            query_params["title"] = title

        params = urlencode(query_params)

        endpoint = f"{self.endpoint}?{params}"

        utils.print_log(
            self._logger,
            "Calling get_secret_by_path endpoint",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint)
        self._normalize_secret_list_response(response)
        return response

    @staticmethod
    def _normalize_secret_list_response(response: requests.Response) -> None:
        """
        Normalize the secrets list response across API versions.

        Starting with API version 3.2, the response is wrapped in an object with
        pagination metadata (e.g. {"TotalCount": 1, "Data": [...]}) instead of
        returning a plain list as previous versions (e.g. 3.1) did. This method
        unwraps the "Data" array so callers always get the list-shaped response,
        regardless of the requested API version.

        Arguments:
            response (requests.Response): The response object to normalize. Its
                ``json`` method is overridden in place when wrapping is detected.
        """

        try:
            payload = response.json()
        except ValueError:
            return

        if isinstance(payload, dict) and "Data" in payload:
            response.json = lambda **kwargs: payload["Data"]

    def _get_file_by_id_req(self, secret_id):
        """
        Get a File secret by File id
        Arguments:
            secret id
        Returns:
            File secret text
        """

        endpoint = f"{self.endpoint}/{secret_id}/file/download"

        utils.print_log(
            self._logger,
            "Calling _get_file_by_id_req endpoint",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint)
        return response

    def get_secret_by_id(self, secret_id: str) -> dict:
        """
        Find a secret by ID.

        API: GET Secrets-Safe/Secrets/{secretId:guid}

        Args:
            secret_id (str): The secret ID (GUID).

        Returns:
            dict: Secret object according requested API version.

        Raises:
            exceptions.LookupError: Raised when no secret is found using secret_id.
        """

        endpoint = f"{self.endpoint}/{secret_id}"

        utils.print_log(
            self._logger,
            "Calling get_secret_by_id endpoint",
            logging.DEBUG,
        )

        try:
            response = self._run_get_request(endpoint)
        except exceptions.LookupError as e:
            raise exceptions.LookupError(f"Error getting secret by id: {e}")

        return response.json()

    def get_secret_shares_by_id(self, secret_id: str) -> list:
        """
        Find secret shares by secret ID.

        API: GET Secrets-Safe/Secrets/{secretId:guid}/shares

        Args:
            secret_id (str): The secret ID (GUID).

        Returns:
            list: List of secret shares.

        Raises:
            exceptions.LookupError: Raised when no shares are found using secret_id.
        """

        endpoint = f"{self.endpoint}/{secret_id}/shares"

        utils.print_log(
            self._logger,
            "Calling get_secret_shares_by_id endpoint",
            logging.DEBUG,
        )

        try:
            response = self._run_get_request(endpoint)
        except exceptions.LookupError as e:
            raise exceptions.LookupError(f"Error getting secret shares by id: {e}")

        return response.json()

    def get_text_secret_by_id(self, secret_id: str) -> dict:
        """
        Get the text value of a text secret by ID.

        API: GET Secrets-Safe/Secrets/{secretId:guid}/text

        Args:
            secret_id (str): The secret ID (GUID).

        Returns:
            dict: Secret text object with the text value.

        Raises:
            exceptions.LookupError: Raised when secret is not found or is not
                a text secret.
        """

        endpoint = f"{self.endpoint}/{secret_id}/text"

        utils.print_log(
            self._logger,
            "Calling get_text_secret_by_id endpoint",
            logging.DEBUG,
        )

        try:
            response = self._run_get_request(endpoint)
        except exceptions.LookupError as e:
            raise exceptions.LookupError(f"Error getting text secret by id: {e}") from e

        return response.json()

    def get_file_secret_metadata(self, secret_id: str) -> dict:
        """
        Get file metadata for a file secret by ID.

        API: GET Secrets-Safe/Secrets/{secretId:guid}/file

        Args:
            secret_id (str): The secret ID (GUID).

        Returns:
            dict: File secret metadata (filename, size, etc.) without the file content.

        Raises:
            exceptions.LookupError: Raised when secret is not found or is not
                a file secret.
        """

        endpoint = f"{self.endpoint}/{secret_id}/file"

        utils.print_log(
            self._logger,
            "Calling get_file_secret_metadata endpoint",
            logging.DEBUG,
        )

        try:
            response = self._run_get_request(endpoint)
        except exceptions.LookupError as e:
            raise exceptions.LookupError(
                f"Error getting file secret metadata: {e}"
            ) from e

        return response.json()

    def get_secret_totp_code(self, secret_id: str) -> dict:
        """
        Get the current one-time (TOTP) code for a credential secret.

        API: GET Secrets-Safe/Secrets/{secretId:guid}/totp/code

        Args:
            secret_id (str): The credential secret ID (GUID).

        Returns:
            dict: The current code and its validity window, with the keys Code,
                ValidFromUtc (inclusive) and ValidToUtc (exclusive).

        Raises:
            exceptions.SecretTypeNotSupportedError: Raised when the secret is a
                text or file secret (400).
            exceptions.TotpNotEnabledError: Raised when the secret is not found or
                does not have TOTP enabled (404).
            exceptions.LookupError: Raised on any other request failure.
        """

        endpoint = f"{self.endpoint}/{secret_id}/totp/code"

        utils.print_log(
            self._logger,
            "Calling get_secret_totp_code endpoint",
            logging.DEBUG,
        )

        try:
            response = self._run_get_request(
                endpoint, expected_status_code=[200, 400, 404]
            )
        except exceptions.LookupError as e:
            raise exceptions.LookupError(f"Error getting secret TOTP code: {e}") from e

        if response.status_code == 200:
            return response.json()

        # 400/404 are accepted above so they can be told apart; sign out here to
        # keep the session cleanup _run_get_request does on any failed request.
        if not self._authentication.sign_app_out():
            utils.print_log(self._logger, "Error running get request", logging.ERROR)

        if response.status_code == 400:
            raise exceptions.SecretTypeNotSupportedError(
                f"Secret {secret_id} is not a credential secret; a TOTP code is "
                f"only available for credential secrets. message: {response.text}"
            )

        raise exceptions.TotpNotEnabledError(
            f"Secret {secret_id} was not found or does not have TOTP enabled. "
            f"Enable TOTP on the secret (API version 3.3) before requesting a "
            f"code. message: {response.text}"
        )

    def create_secret_share(self, secret_id: str, folder_id: str) -> dict:
        """
        Create a shared reference to a secret in a specific folder.

        API: POST Secrets-Safe/Secrets/{secretId:guid}/shares/{folderId:guid}

        Args:
            secret_id (str): The secret ID (GUID).
            folder_id (str): The folder ID (GUID) where the secret will be shared.

        Returns:
            dict: Created shared secret object.

        Raises:
            exceptions.CreationError: Raised when creation of the secret share fails.
        """

        endpoint = f"{self.endpoint}/{secret_id}/shares/{folder_id}"

        utils.print_log(
            self._logger,
            "Calling create_secret_share endpoint",
            logging.DEBUG,
        )

        response = self._run_post_request(endpoint, {})
        return response.json()

    def delete_secret_share(self, secret_id: str, folder_id: str) -> None:
        """
        Delete a shared reference of a secret from a specific folder.

        API: DELETE Secrets-Safe/Secrets/{secretId:guid}/shares/{folderId:guid}

        Args:
            secret_id (str): The secret ID (GUID).
            folder_id (str): The folder ID (GUID) to remove sharing from.

        Returns:
            None: If deletion is successful no exceptions.DeletionError is raised.

        Raises:
            exceptions.DeletionError: Raised when deletion of the secret share fails.
        """

        endpoint = f"{self.endpoint}/{secret_id}/shares/{folder_id}"

        utils.print_log(
            self._logger,
            "Calling delete_secret_share endpoint",
            logging.DEBUG,
        )

        self._run_delete_request(endpoint, expected_status_code=204)

    def delete_all_secret_shares(self, secret_id: str) -> None:
        """
        Delete all shared references of a secret.

        API: DELETE Secrets-Safe/Secrets/{secretId:guid}/shares

        Args:
            secret_id (str): The secret ID (GUID).

        Returns:
            None: If deletion is successful no exceptions.DeletionError is raised.

        Raises:
            exceptions.DeletionError: Raised when deletion of the secret shares fails.
        """

        endpoint = f"{self.endpoint}/{secret_id}/shares"

        utils.print_log(
            self._logger,
            "Calling delete_all_secret_shares endpoint",
            logging.DEBUG,
        )

        self._run_delete_request(endpoint, expected_status_code=204)

    def list_secrets(
        self,
        path: str = None,
        separator: str = None,
        title: str = None,
        afterdate: str = None,
        limit: int = None,
        offset: int = None,
        favorite: bool = None,
    ) -> list:
        """
        Returns a list of secrets with the option to filter the list using query
        parameters.

        API: GET Secrets-Safe/Secrets

        Args:
            path (str): the full path to the secret.
            separator (str): the separator used in the path above. Default is /.
            title (str): the full title of the secret.
            afterdate (str): filter by modified or created on, after, or equal to the
            given date. Must be in the following UTC format: yyyy-MM-ddTHH:mm:ssZ.
            limit (int): limit the results.
            offset (int): skip the first (offset) number of secrets.
            favorite (bool): filter by the calling user's favorite secrets. If
                True, only favorite secrets are returned.
        Returns:
            list: List of secrets matching specified arguments.
        """

        params = {
            "path": path,
            "separator": separator,
            "title": title,
            "afterdate": afterdate,
            "limit": limit,
            "offset": offset,
        }

        query_params = {k: v for k, v in params.items() if v is not None}

        if self._decrypt is not None:
            query_params["decrypt"] = str(self._decrypt).lower()

        if favorite is not None:
            query_params["favorite"] = str(favorite).lower()

        query_string = urlencode(query_params)
        endpoint = f"{self.endpoint}?{query_string}" if query_string else self.endpoint

        utils.print_log(self._logger, "Calling list_secrets endpoint", logging.DEBUG)

        try:
            response = self._run_get_request(endpoint)
        except exceptions.LookupError as e:
            raise exceptions.LookupError(f"Error getting secrets: {e}")

        return response.json()

    def list_secrets_by_folder_id(self, folder_id: str = None) -> list:
        """
        Returns the list of secrets held in the given folder.

        API: GET Secrets-Safe/Folders/{folderId:guid}/secrets

        Args:
            folder_id (str): The folder GUID.

        Returns:
            list: List of secrets for the given folder_id.

        Raises:
            exceptions.OptionsError: When folder_id is not provided.
            exceptions.LookupError: When the get request fails.
        """

        if not folder_id:
            raise exceptions.OptionsError("folder_id is required")

        endpoint = f"/secrets-safe/folders/{folder_id}/secrets"

        utils.print_log(
            self._logger,
            "Calling list_secrets_by_folder_id endpoint",
            logging.DEBUG,
        )

        try:
            response = self._run_get_request(endpoint)
        except exceptions.LookupError as e:
            raise exceptions.LookupError(f"Error getting secrets by folder: {e}")

        return response.json()

    def create_secret(
        self,
        title: str,
        folder_id: str,
        description: str = None,
        username: str = None,  # Used for normal Secrets
        password: str = None,  # Used for normal Secrets
        text: str = None,  # Used for Text Secrets
        file_path: str = None,  # Used for File Secrets
        owner_id: int = None,
        owner_type: str = None,
        owners: list = None,
        password_rule_id: int = None,
        notes: str = None,
        urls: list = None,
        totp_enabled: bool = None,  # Used for normal Secrets (API 3.3+)
        totp_secret_key: str = None,  # Used for normal Secrets (API 3.3+)
    ) -> dict:
        """
        Creates a Secret (Normal Secret, Text o File) using provided parameters
        according configured version.

        API:
            - POST Secrets-Safe/Folders/{folderId:guid}/secrets
            - POST Secrets-Safe/Folders/{folderId:guid}/secrets/text
            - POST Secrets-Safe/Folders/{folderId:guid}/secrets/file

        Args:
            title (str): The full title of the secret.
            folder_id (str): The GUID of the folder where secrets will be created.
            description (str, optional): The description of the secret.
            username (str, optional): The username for normal Secrets.
            password (str, optional): The password for normal Secrets.
            text (str, optional): The text content for Text Secrets.
            file_path (str, optional): The path to the file for File Secrets.
            owner_id (int, optional): The ID of the owner.
            owner_type (str, optional): The type of the owner.
            owners (list, optional): A list of owners.
            password_rule_id (int, optional): The ID of the password rule.
            notes (str, optional): Notes about the secret.
            urls (list, optional): A list of URLs with this format
                {'Id': GUID, 'CredentialId': GUID, 'Url': string}.
            totp_enabled (bool, optional): Enables TOTP on a normal Secret. Requires
                API version 3.3. When True, totp_secret_key is required.
            totp_secret_key (str, optional): The TOTP seed, as a Base32 string or an
                otpauth:// URI. Requires totp_enabled=True. Never returned on reads.

        Returns:
            dict: Created secret object according requested API version.
        """

        attributes = {
            "title": title,
            "description": description,
            "notes": notes,
            "owner_id": owner_id,
            "owner_type": owner_type,
            "owners": owners,
            "urls": urls,
            "totp_enabled": totp_enabled,
            "totp_secret_key": totp_secret_key,
        }

        # Identify which request body is being used
        if username:
            attributes.update(
                {
                    "username": username,
                    "password": password,
                }
            )

            self.validate(
                attributes,
                operation="create_credential_secret",
                version=self._authentication._api_version,
            )

            partial_endpoint = "secrets"
            utils.print_log(
                self._logger,
                f"Creating a normal secret: {partial_endpoint}",
                logging.DEBUG,
            )
            req_structure = self.get_request_body_version(
                secrets_fields, POST_SECRETS_SAFE_FOLDERS_FOLDERID
            )
        elif text:
            attributes.update({"text": text})

            self.validate(
                attributes,
                operation="create_text_secret",
                version=self._authentication._api_version,
            )

            partial_endpoint = "secrets/text"
            utils.print_log(
                self._logger,
                f"Creating a text secret: {partial_endpoint}",
                logging.DEBUG,
            )
            req_structure = self.get_request_body_version(
                secrets_fields, POST_SECRETS_SAFE_FOLDERS_FOLDERID_TEXT
            )
        elif file_path:
            attributes.update({"file_path": file_path})

            self.validate(
                attributes,
                operation="create_file_secret",
                version=self._authentication._api_version,
            )

            partial_endpoint = "secrets/file"
            utils.print_log(
                self._logger,
                f"Creating a file secret: {partial_endpoint}",
                logging.DEBUG,
            )
            req_structure = self.get_request_body_version(
                secrets_fields, POST_SECRETS_SAFE_FOLDERS_FOLDERID_FILE
            )
        else:
            raise exceptions.IncompleteArgumentsError(
                "Either username, text or file_path is required"
            )

        req_body = self.generate_request_body(
            req_structure,
            title=title,
            description=description,
            username=username,
            password=password,
            text=text,
            file_path=file_path,
            owner_id=owner_id,
            owner_type=owner_type,
            owners=owners,
            password_rule_id=password_rule_id,
            notes=notes,
            urls=urls,
            folder_id=folder_id,
            totp_enabled=totp_enabled,
            totp_secret_key=totp_secret_key,
        )

        endpoint = f"/secrets-safe/folders/{folder_id}/{partial_endpoint}"

        if partial_endpoint == "secrets/file":
            utils.print_log(
                self._logger,
                "Calling _run_post_file_request",
                logging.DEBUG,
            )
            response = self._run_post_file_request(
                endpoint,
                file_path=file_path,
                payload=req_body,
            )
        else:
            utils.print_log(
                self._logger,
                "Calling _run_post_request",
                logging.DEBUG,
            )
            response = self._run_post_request(endpoint, req_body)

        return response.json()

    def delete_secret_by_id(self, secret_id: str) -> None:
        """
        Delete a secret by ID.

        API: DELETE Secrets-Safe/Secrets/{secretId:guid}/

        Args:
            secret_id (str): The secret ID (GUID).

        Returns:
            None: If deletion is successful no exceptions.DeletionError is raised.
        """

        endpoint = f"{self.endpoint}/{secret_id}"

        utils.print_log(
            self._logger,
            "Calling delete_secret_by_id endpoint",
            logging.DEBUG,
        )
        self._run_delete_request(endpoint)

    def update_secret(
        self,
        secret_id: str,
        folder_id: str = None,
        title: str = None,
        description: str = None,
        username: str = None,  # Used for normal Secrets
        password: str = None,  # Used for normal Secrets
        text: str = None,  # Used for Text Secrets
        file_path: str = None,  # Used for File Secrets
        owner_id: int = None,
        owner_type: str = None,
        owners: list = None,
        password_rule_id: int = None,
        notes: str = None,
        urls: list = None,
        totp_enabled: bool = None,  # Used for normal Secrets (API 3.3+)
        totp_secret_key: str = None,  # Used for normal Secrets (API 3.3+)
    ) -> dict | None:
        """
        Updates a Secret (Normal Secret, Text o File) using provided parameters
        according configured version.

        API:
            - PUT Secrets-Safe/Secrets/{secretId:guid}/
            - PUT Secrets-Safe/Secrets/{secretId:guid}/text
            - PUT Secrets-Safe/Secrets/{secretId:guid}/file

        Args:
            secret_id (str): The ID of the secret to update.
            folder_id (str): The GUID of the folder where secrets will be created.
            title (str, optional): The full title of the secret.
            description (str, optional): The description of the secret.
            username (str, optional): The username for normal Secrets.
            password (str, optional): The password for normal Secrets.
            text (str, optional): The text content for Text Secrets.
            file_path (str, optional): The path to the file for File Secrets.
            owner_id (int, optional): The ID of the owner.
            owner_type (str, optional): The type of the owner.
            owners (list, optional): A list of owners.
            password_rule_id (int, optional): The ID of the password rule.
            notes (str, optional): Notes about the secret.
            urls (list, optional): A list of URLs with this format
                {'Id': GUID, 'CredentialId': GUID, 'Url': string}.
            totp_enabled (bool, optional): TOTP setting for a normal Secret. Requires
                API version 3.3. None leaves TOTP untouched, False disables it and
                True provisions or replaces the seed given in totp_secret_key.
            totp_secret_key (str, optional): The TOTP seed, as a Base32 string or an
                otpauth:// URI. Requires totp_enabled=True. Never returned on reads.

        Returns:
            dict: Created secret object according requested API version.
        """

        attributes = {
            "title": title,
            "description": description,
            "notes": notes,
            "folder_id": folder_id,
            "owner_id": owner_id,
            "owner_type": owner_type,
            "owners": owners,
            "urls": urls,
            "totp_enabled": totp_enabled,
            "totp_secret_key": totp_secret_key,
        }

        # Identify which request body is being used and validate accordingly
        partial_endpoint = ""
        if username:
            attributes.update(
                {
                    "username": username,
                    "password": password,
                    "password_rule_id": password_rule_id,
                }
            )

            self.validate(
                attributes,
                operation="update_credential_secret",
                version=self._authentication._api_version,
            )

            utils.print_log(
                self._logger,
                f"Updating a normal secret: {partial_endpoint}",
                logging.DEBUG,
            )
            req_structure = self.get_request_body_version(
                secrets_fields, PUT_SECRETS_SAFE_SECRETS_SECRETID
            )
        elif text:
            attributes.update({"text": text})
            self.validate(
                attributes,
                operation="update_text_secret",
                version=self._authentication._api_version,
            )

            partial_endpoint = "text"
            utils.print_log(
                self._logger,
                f"Updating a text secret: {partial_endpoint}",
                logging.DEBUG,
            )
            req_structure = self.get_request_body_version(
                secrets_fields, PUT_SECRETS_SAFE_SECRETS_SECRETID_TEXT
            )
        elif file_path:
            attributes.update({"file_path": file_path})
            self.validate(
                attributes,
                operation="update_file_secret",
                version=self._authentication._api_version,
            )

            partial_endpoint = "file"
            utils.print_log(
                self._logger,
                f"Updating a file secret: {partial_endpoint}",
                logging.DEBUG,
            )
            req_structure = self.get_request_body_version(
                secrets_fields, PUT_SECRETS_SAFE_SECRETS_SECRETID_FILE
            )
        else:
            raise exceptions.IncompleteArgumentsError(
                "Either username, text or file_path is required"
            )

        req_body = self.generate_request_body(
            req_structure,
            title=title,
            description=description,
            username=username,
            password=password,
            text=text,
            file_path=file_path,
            owner_id=owner_id,
            owner_type=owner_type,
            owners=owners,
            password_rule_id=password_rule_id,
            notes=notes,
            urls=urls,
            folder_id=folder_id,
            totp_enabled=totp_enabled,
            totp_secret_key=totp_secret_key,
        )

        endpoint = f"{self.endpoint}/{secret_id}/{partial_endpoint}"

        if file_path:
            utils.print_log(
                self._logger,
                "Calling _run_put_file_request",
                logging.DEBUG,
            )
            _ = self._run_put_file_request(
                endpoint,
                file_path=file_path,
                payload=req_body,
            )
            # File PUT request returns a 204 No content, so no need to return anything
            return
        else:
            utils.print_log(
                self._logger,
                "Calling _run_put_request",
                logging.DEBUG,
            )
            response = self._run_put_request(endpoint, req_body)

        return response.json()

    def move_secrets(
        self,
        secret_ids: list,
        share_ids: list,
        destination_folder_id: str,
        duplicate_name_action: str,
    ) -> dict:
        """
        Moves one or more secrets and/or shares to a different folder.

        API: PUT Secrets-Safe/Secrets/move

        Args:
            secret_ids (list): List of secret IDs (GUIDs) to move.
            share_ids (list): List of share IDs (GUIDs) to move.
            destination_folder_id (str): The GUID of the destination folder.
            duplicate_name_action (str): Action to take if a secret with
                the same name exists in the destination folder. Options are
                "Stop", "Rename", or "Skip".

        Returns:
            dict: Response object indicating the result of the move operation.
        """

        attributes = {
            "secret_ids": secret_ids,
            "share_ids": share_ids,
            "destination_folder_id": destination_folder_id,
            "duplicate_name_action": duplicate_name_action,
        }

        self.validate(
            attributes,
            operation="move_secrets",
            version=self._authentication._api_version,
        )

        payload = {key.replace("_", ""): value for key, value in attributes.items()}

        endpoint = f"{self.endpoint}/move"

        utils.print_log(
            self._logger,
            "Calling move_secrets endpoint",
            logging.DEBUG,
        )
        response = self._run_put_request(endpoint, payload)

        return response.json()

    def set_secret_favorite(self, secret_id: str, is_favorite: bool) -> None:
        """
        Marks or unmarks a secret as favorite for the calling user. Idempotent:
        setting the same state twice is a no-op.

        API: PUT Secrets-Safe/Secrets/{secretId:guid}/favorite

        Args:
            secret_id (str): The secret ID (GUID).
            is_favorite (bool): True to mark the secret as favorite, False to
                unmark it.

        Returns:
            None: The endpoint returns 204 No Content on success.
        """

        attributes = {"is_favorite": is_favorite}

        self.validate(
            attributes,
            operation="set_secret_favorite",
            version=self._authentication._api_version,
        )

        payload = {"Favorite": is_favorite}
        endpoint = f"{self.endpoint}/{secret_id}/favorite"

        utils.print_log(
            self._logger,
            "Calling set_secret_favorite endpoint",
            logging.DEBUG,
        )
        self._run_put_request(endpoint, payload, expected_status_code=204)

    def get_secret_versions(self, secret_id: str) -> dict:
        """
        Get the version history for a secret by ID.

        API: GET Secrets-Safe/Secrets/{secretId:guid}/versions

        Args:
            secret_id (str): The secret ID (GUID).

        Returns:
            dict: SecretVersionHistoryDto with CredentialId, SecretType, Versions
                (list of version entries), and ChangeFrequency.

        Raises:
            exceptions.LookupError: Raised when the secret is not found.
        """

        endpoint = f"{self.endpoint}/{secret_id}/versions"

        utils.print_log(
            self._logger,
            "Calling get_secret_versions endpoint",
            logging.DEBUG,
        )

        try:
            response = self._run_get_request(endpoint)
        except exceptions.LookupError as e:
            raise exceptions.LookupError(f"Error getting secret versions: {e}") from e

        return response.json()

    def get_secret_password_version(self, secret_id: str, version_id: str) -> str:
        """
        Get the historical password value of a credential secret for a specific
        version.

        API: GET Secrets-Safe/Secrets/password/{secretId:guid}/versions/{versionId:guid}

        Args:
            secret_id (str): The secret ID (GUID).
            version_id (str): The version ID (GUID).

        Returns:
            str: The historical password value.

        Raises:
            exceptions.LookupError: Raised when the secret or version is not found.
        """

        endpoint = f"{self.endpoint}/password/{secret_id}/versions/{version_id}"

        utils.print_log(
            self._logger,
            "Calling get_secret_password_version endpoint",
            logging.DEBUG,
        )

        try:
            response = self._run_get_request(endpoint)
        except exceptions.LookupError as e:
            raise exceptions.LookupError(
                f"Error getting secret password version: {e}"
            ) from e

        return response.text

    def get_secret_text_version(self, secret_id: str, version_id: str) -> str:
        """
        Get the historical text value of a text secret for a specific version.

        API: GET Secrets-Safe/Secrets/text/{secretId:guid}/versions/{versionId:guid}

        Args:
            secret_id (str): The secret ID (GUID).
            version_id (str): The version ID (GUID).

        Returns:
            str: The historical text value.

        Raises:
            exceptions.LookupError: Raised when the secret or version is not found.
        """

        endpoint = f"{self.endpoint}/text/{secret_id}/versions/{version_id}"

        utils.print_log(
            self._logger,
            "Calling get_secret_text_version endpoint",
            logging.DEBUG,
        )

        try:
            response = self._run_get_request(endpoint)
        except exceptions.LookupError as e:
            raise exceptions.LookupError(
                f"Error getting secret text version: {e}"
            ) from e

        return response.text

    def get_secret_file_version(self, secret_id: str, version_id: str) -> str:
        """
        Get the historical file content of a file secret for a specific version.

        API: GET Secrets-Safe/Secrets/file/{secretId:guid}/versions/{versionId:guid}

        Args:
            secret_id (str): The secret ID (GUID).
            version_id (str): The version ID (GUID).

        Returns:
            str: The historical file content.

        Raises:
            exceptions.LookupError: Raised when the secret or version is not found.
        """

        endpoint = f"{self.endpoint}/file/{secret_id}/versions/{version_id}"

        utils.print_log(
            self._logger,
            "Calling get_secret_file_version endpoint",
            logging.DEBUG,
        )

        try:
            response = self._run_get_request(endpoint)
        except exceptions.LookupError as e:
            raise exceptions.LookupError(
                f"Error getting secret file version: {e}"
            ) from e

        return response.text

    def rollback_secret_version(self, secret_id: str, version_id: str) -> None:
        """
        Rolls a secret back to a specific version, making it the active version.
        Requires ReadWrite permission.

        API: POST Secrets-Safe/Secrets/{secretId:guid}/versions/{versionId:guid}/
            rollback

        Args:
            secret_id (str): The secret ID (GUID).
            version_id (str): The version ID (GUID) to roll back to.

        Returns:
            None: The endpoint returns 204 No Content on success.

        Raises:
            exceptions.CreationError: Raised when the rollback fails.
        """

        endpoint = f"{self.endpoint}/{secret_id}/versions/{version_id}/rollback"

        utils.print_log(
            self._logger,
            "Calling rollback_secret_version endpoint",
            logging.DEBUG,
        )
        self._run_post_request(endpoint, {}, expected_status_code=204)
