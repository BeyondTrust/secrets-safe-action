from .config import configure_logging

__version__ = "3.5.1"  # x-release-please-version
__library_name__ = "Secret Safe Library"

configure_logging()
