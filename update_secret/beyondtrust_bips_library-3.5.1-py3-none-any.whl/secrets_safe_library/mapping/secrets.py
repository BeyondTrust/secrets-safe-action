"""
This file contains the fields mapping for each endpoint and version related to SECRETS.

More info for the fields included in each version:
- https://docs.beyondtrust.com/bips/docs/passwordsafe-api
- https://docs.beyondtrust.com/bips/docs/secrets-safe-api
"""

from secrets_safe_library.constants.endpoints import (
    GET_SECRETS_SAFE_SECRETS,
    GET_SECRETS_SAFE_SECRETS_SECRETID,
    GET_SECRETS_SAFE_SECRETS_SECRETID_FILE,
    GET_SECRETS_SAFE_SECRETS_SECRETID_SHARES,
    GET_SECRETS_SAFE_SECRETS_SECRETID_TEXT,
    GET_SECRETS_SAFE_SECRETS_SECRETID_TOTP_CODE,
    GET_SECRETS_SAFE_SECRETS_SECRETID_VERSIONS,
    POST_SECRETS_SAFE_FOLDERS_FOLDERID,
    POST_SECRETS_SAFE_FOLDERS_FOLDERID_FILE,
    POST_SECRETS_SAFE_FOLDERS_FOLDERID_TEXT,
    PUT_SECRETS_SAFE_SECRETS_MOVE,
    PUT_SECRETS_SAFE_SECRETS_SECRETID,
    PUT_SECRETS_SAFE_SECRETS_SECRETID_FILE,
    PUT_SECRETS_SAFE_SECRETS_SECRETID_TEXT,
)
from secrets_safe_library.constants.versions import Version

# GET response field lists - V3_2 adds SecretValueModifiedOn to the V3_1 shape and
# V3_3 adds the read-only TOTP state from BaseSecretsSafeSecretModel. The TOTP
# seed itself is never returned on any read path.
TOTP_READ_FIELDS = ["TotpEnabled", "TotpParameters"]

GET_SECRETS_V3_1 = [
    "Id",
    "Title",
    "Description",
    "Username",
    "Password",
    "FileName",
    "FileHash",
    "Text",
    "SecretType",
    "FolderId",
    "CreatedOn",
    "CreatedBy",
    "ModifiedOn",
    "ModifiedBy",
    "Folder",
    "FolderPath",
    "Owners",
    "Notes",
    "Urls",
    "IsFavorite",
]
GET_SECRETS_V3_2 = [*GET_SECRETS_V3_1, "SecretValueModifiedOn"]
GET_SECRETS_V3_3 = [*GET_SECRETS_V3_2, *TOTP_READ_FIELDS]

GET_SECRET_CREDENTIAL_V3_1 = [
    "Id",
    "Title",
    "Description",
    "Username",
    "Password",
    "FolderId",
    "CreatedOn",
    "CreatedBy",
    "ModifiedOn",
    "ModifiedBy",
    "Folder",
    "FolderPath",
    "Owners",
    "Notes",
    "Urls",
    "IsFavorite",
]
GET_SECRET_CREDENTIAL_V3_2 = [*GET_SECRET_CREDENTIAL_V3_1, "SecretValueModifiedOn"]
GET_SECRET_CREDENTIAL_V3_3 = [*GET_SECRET_CREDENTIAL_V3_2, *TOTP_READ_FIELDS]

GET_SECRET_TEXT_V3_1 = [
    "Id",
    "Title",
    "Description",
    "Text",
    "FolderId",
    "CreatedOn",
    "CreatedBy",
    "ModifiedOn",
    "ModifiedBy",
    "Folder",
    "FolderPath",
    "Owners",
    "Notes",
    "Urls",
    "IsFavorite",
]
GET_SECRET_TEXT_V3_2 = [*GET_SECRET_TEXT_V3_1, "SecretValueModifiedOn"]
GET_SECRET_TEXT_V3_3 = [*GET_SECRET_TEXT_V3_2, *TOTP_READ_FIELDS]

GET_SECRET_FILE_V3_1 = [
    "Id",
    "Title",
    "Description",
    "FolderId",
    "CreatedOn",
    "CreatedBy",
    "ModifiedOn",
    "ModifiedBy",
    "Folder",
    "FolderPath",
    "Owners",
    "Notes",
    "FileName",
    "FileHash",
    "Urls",
    "IsFavorite",
]
GET_SECRET_FILE_V3_2 = [*GET_SECRET_FILE_V3_1, "SecretValueModifiedOn"]
GET_SECRET_FILE_V3_3 = [*GET_SECRET_FILE_V3_2, *TOTP_READ_FIELDS]

# POST/PUT request bodies - V3_2 is identical to V3_1 for every secret type
# V3_3 adds write-only TOTP fields to credential secrets only. TotpEnabled is
# tri-state on update: omitted leaves TOTP untouched, False disables it and
# True provisions or replaces the seed sent in TotpSecretKey.
TOTP_WRITE_FIELDS = {"TotpEnabled": bool, "TotpSecretKey": str}

POST_CREDENTIAL_SECRET_V3_1 = {
    "Title": str,
    "Description": str,
    "Username": str,
    "Password": str,
    "Owners": [{"GroupId": int, "UserId": int, "Name": str, "Email": str}],
    "PasswordRuleID": int,
    "Notes": str,
    "Urls": [{"Id": str, "CredentialId": str, "Url": str}],
}

POST_TEXT_SECRET_V3_1 = {
    "Title": str,
    "Description": str,
    "Text": str,
    "Owners": [{"GroupId": int, "UserId": int, "Name": str, "Email": str}],
    "Notes": str,
    "FolderId": str,
    "Urls": [{"Id": str, "CredentialId": str, "Url": str}],
}

POST_FILE_SECRET_V3_1 = {
    "Title": str,
    "Description": str,
    "Owners": [{"GroupId": int, "UserId": int, "Name": str, "Email": str}],
    "Notes": str,
    "FileName": str,
    "Urls": [{"Id": str, "CredentialId": str, "Url": str}],
}

PUT_CREDENTIAL_SECRET_V3_1 = {
    "FolderId": str,
    "Title": str,
    "Description": str,
    "Username": str,
    "Password": str,
    "Owners": [{"GroupId": int, "UserId": int, "Name": str, "Email": str}],
    "PasswordRuleID": int,
    "Notes": str,
    "Urls": [{"Id": str, "CredentialId": str, "Url": str}],
}

POST_CREDENTIAL_SECRET_V3_3 = {**POST_CREDENTIAL_SECRET_V3_1, **TOTP_WRITE_FIELDS}
PUT_CREDENTIAL_SECRET_V3_3 = {**PUT_CREDENTIAL_SECRET_V3_1, **TOTP_WRITE_FIELDS}

PUT_TEXT_SECRET_V3_1 = {
    "FolderId": str,
    "Title": str,
    "Description": str,
    "Text": str,
    "Owners": [{"GroupId": int, "UserId": int, "Name": str, "Email": str}],
    "Notes": str,
    "Urls": [{"Id": str, "CredentialId": str, "Url": str}],
}

PUT_FILE_SECRET_V3_1 = {
    "FolderId": str,
    "Title": str,
    "Description": str,
    "Owners": [{"GroupId": int, "UserId": int, "Name": str, "Email": str}],
    "Notes": str,
    "FileName": str,
    "Urls": [{"Id": str, "CredentialId": str, "Url": str}],
}

fields = {
    GET_SECRETS_SAFE_SECRETS: {
        Version.V3_0.value: [
            "Id",
            "Title",
            "Description",
            "Username",
            "Password",
            "FileName",
            "FileHash",
            "Text",
            "SecretType",
            "OwnerId",
            "FolderId",
            "CreatedOn",
            "CreatedBy",
            "ModifiedOn",
            "ModifiedBy",
            "Owner",
            "Folder",
            "FolderPath",
            "Owners",
            "OwnerType",
            "Notes",
            "Urls",
        ],
        Version.V3_1.value: GET_SECRETS_V3_1,
        Version.V3_2.value: GET_SECRETS_V3_2,
        Version.V3_3.value: GET_SECRETS_V3_3,
    },
    GET_SECRETS_SAFE_SECRETS_SECRETID: {
        Version.V3_0.value: [
            "Id",
            "Title",
            "Description",
            "Username",
            "Password",
            "OwnerId",
            "FolderId",
            "CreatedOn",
            "CreatedBy",
            "ModifiedOn",
            "ModifiedBy",
            "Owner",
            "Folder",
            "FolderPath",
            "Owners",
            "Notes",
            "Urls",
        ],
        Version.V3_1.value: GET_SECRET_CREDENTIAL_V3_1,
        Version.V3_2.value: GET_SECRET_CREDENTIAL_V3_2,
        Version.V3_3.value: GET_SECRET_CREDENTIAL_V3_3,
    },
    GET_SECRETS_SAFE_SECRETS_SECRETID_TEXT: {
        Version.V3_0.value: [
            "Id",
            "Title",
            "Description",
            "Text",
            "OwnerId",
            "FolderId",
            "CreatedOn",
            "CreatedBy",
            "ModifiedOn",
            "ModifiedBy",
            "Owner",
            "Folder",
            "FolderPath",
            "Owners",
            "OwnerType",
            "Notes",
            "Urls",
        ],
        Version.V3_1.value: GET_SECRET_TEXT_V3_1,
        Version.V3_2.value: GET_SECRET_TEXT_V3_2,
        Version.V3_3.value: GET_SECRET_TEXT_V3_3,
    },
    GET_SECRETS_SAFE_SECRETS_SECRETID_SHARES: {
        Version.DEFAULT.value: [
            "SecretId",
            "FolderId",
            "FolderPath",
            "SecretName",
        ],
    },
    # SecretsSafeTotpCodeModel - introduced with API 3.3, but its shape does not
    # vary with the requested version, so it is registered as DEFAULT.
    GET_SECRETS_SAFE_SECRETS_SECRETID_TOTP_CODE: {
        Version.DEFAULT.value: ["Code", "ValidFromUtc", "ValidToUtc"],
    },
    GET_SECRETS_SAFE_SECRETS_SECRETID_VERSIONS: {
        Version.DEFAULT.value: [
            "Id",
            "VersionNumber",
            "IsActive",
            "CreatedOn",
            "CreatedBy",
            "FileName",
            "IsHSMEncrypted",
        ],
    },
    GET_SECRETS_SAFE_SECRETS_SECRETID_FILE: {
        Version.V3_0.value: [
            "Id",
            "Title",
            "Description",
            "OwnerId",
            "FolderId",
            "CreatedOn",
            "CreatedBy",
            "ModifiedOn",
            "ModifiedBy",
            "Owner",
            "Folder",
            "FolderPath",
            "Owners",
            "OwnerType",
            "Notes",
            "FileName",
            "FileHash",
            "Urls",
        ],
        Version.V3_1.value: GET_SECRET_FILE_V3_1,
        Version.V3_2.value: GET_SECRET_FILE_V3_2,
        Version.V3_3.value: GET_SECRET_FILE_V3_3,
    },
    POST_SECRETS_SAFE_FOLDERS_FOLDERID: {
        Version.V3_0.value: {
            "Title": str,
            "Description": str,
            "Username": str,
            "Password": str,
            "OwnerId": int,
            "OwnerType": str,
            "Owners": [{"OwnerId": int, "Owner": str, "Email": str}],
            "PasswordRuleID": int,
            "Notes": str,
            "Urls": [{"Id": str, "CredentialId": str, "Url": str}],
        },
        Version.V3_1.value: POST_CREDENTIAL_SECRET_V3_1,
        Version.V3_2.value: POST_CREDENTIAL_SECRET_V3_1,
        Version.V3_3.value: POST_CREDENTIAL_SECRET_V3_3,
    },
    POST_SECRETS_SAFE_FOLDERS_FOLDERID_TEXT: {
        Version.V3_0.value: {
            "Title": str,
            "Description": str,
            "Text": str,
            "OwnerId": int,
            "OwnerType": str,
            "Owners": [{"OwnerId": int, "Owner": str, "Email": str}],
            "Notes": str,
            "FolderId": str,
            "Urls": [{"Id": str, "CredentialId": str, "Url": str}],
        },
        Version.V3_1.value: POST_TEXT_SECRET_V3_1,
        Version.V3_2.value: POST_TEXT_SECRET_V3_1,
        Version.V3_3.value: POST_TEXT_SECRET_V3_1,
    },
    POST_SECRETS_SAFE_FOLDERS_FOLDERID_FILE: {
        Version.V3_0.value: {
            "Title": str,
            "Description": str,
            "OwnerId": int,
            "OwnerType": str,
            "Owners": [{"OwnerId": int, "Owner": str, "Email": str}],
            "Notes": str,
            "FileName": str,
            "Urls": [{"Id": str, "CredentialId": str, "Url": str}],
        },
        Version.V3_1.value: POST_FILE_SECRET_V3_1,
        Version.V3_2.value: POST_FILE_SECRET_V3_1,
        Version.V3_3.value: POST_FILE_SECRET_V3_1,
    },
    PUT_SECRETS_SAFE_SECRETS_SECRETID: {
        Version.V3_0.value: {
            "FolderId": str,
            "Title": str,
            "Description": str,
            "Username": str,
            "Password": str,
            "OwnerId": int,
            "OwnerType": str,
            "Owners": [{"OwnerId": int, "Owner": str, "Email": str}],
            "PasswordRuleID": int,
            "Notes": str,
            "Urls": [{"Id": str, "CredentialId": str, "Url": str}],
        },
        Version.V3_1.value: PUT_CREDENTIAL_SECRET_V3_1,
        Version.V3_2.value: PUT_CREDENTIAL_SECRET_V3_1,
        Version.V3_3.value: PUT_CREDENTIAL_SECRET_V3_3,
    },
    PUT_SECRETS_SAFE_SECRETS_SECRETID_TEXT: {
        Version.V3_0.value: {
            "FolderId": str,
            "Title": str,
            "Description": str,
            "Text": str,
            "OwnerId": int,
            "OwnerType": str,
            "Owners": [{"OwnerId": int, "Owner": str, "Email": str}],
            "Notes": str,
            "Urls": [{"Id": str, "CredentialId": str, "Url": str}],
        },
        Version.V3_1.value: PUT_TEXT_SECRET_V3_1,
        Version.V3_2.value: PUT_TEXT_SECRET_V3_1,
        Version.V3_3.value: PUT_TEXT_SECRET_V3_1,
    },
    PUT_SECRETS_SAFE_SECRETS_SECRETID_FILE: {
        Version.V3_0.value: {
            "FolderId": str,
            "Title": str,
            "Description": str,
            "OwnerId": int,
            "OwnerType": str,
            "Owners": [{"OwnerId": int, "Owner": str, "Email": str}],
            "Notes": str,
            "FileName": str,
            "Urls": [{"Id": str, "CredentialId": str, "Url": str}],
        },
        Version.V3_1.value: PUT_FILE_SECRET_V3_1,
        Version.V3_2.value: PUT_FILE_SECRET_V3_1,
        Version.V3_3.value: PUT_FILE_SECRET_V3_1,
    },
    PUT_SECRETS_SAFE_SECRETS_MOVE: {
        Version.DEFAULT.value: {
            "Errors": [str],
            "DestinationFolderId": str,
            "SecretsCount": int,
            "SharesCount": int,
            "SecretsMovedCount": int,
            "SharesMovedCount": int,
            "SecretsRenamed": [str],
            "SecretsSkipped": [str],
            "SecretsFailedValidation": [str],
            "SecretsNotFound": [str],
            "SharesFailedValidation": [str],
            "SharesNotFound": [str],
            "SharesNotMovedToDifferentSafe": [str],
            "SharesRemoved": [str],
        },
    },
}
