"""
This file contains the fields mapping for each endpoint and version related to
CREDENTIALS.

More info for the fields included in each endpoint and version:
- https://docs.beyondtrust.com/bips/docs/passwordsafe-api
"""

from secrets_safe_library.constants.endpoints import (
    GET_CREDENTIALS_ALIASID,
    GET_CREDENTIALS_MANAGEDACCOUNTID,
    GET_CREDENTIALS_REQUESTID,
    POST_MANAGED_SYSTEMS_ID_MANAGED_ACCOUNTS_CREDENTIALS_CHANGE,
    PUT_CREDENTIALS_BY_NAMES,
    PUT_CREDENTIALS_BY_PATH,
)
from secrets_safe_library.constants.versions import Version

fields = {
    GET_CREDENTIALS_REQUESTID: {
        Version.DEFAULT.value: [
            "Credentials",
        ],
    },
    GET_CREDENTIALS_ALIASID: {
        Version.DEFAULT.value: [
            "AliasID",
            "AliasName",
            "SystemID",
            "SystemName",
            "AccountID",
            "AccountName",
            "DomainName",
            "Password",
            "PrivateKey",
            "Passphrase",
        ],
    },
    GET_CREDENTIALS_MANAGEDACCOUNTID: {
        Version.DEFAULT.value: [
            "Code",
        ],
    },
    PUT_CREDENTIALS_BY_NAMES: {
        Version.DEFAULT.value: {
            "Password": str,
            "PublicKey": str,
            "PrivateKey": str,
            "Passphrase": str,
            "UpdateSystem": bool,
        },
    },
    PUT_CREDENTIALS_BY_PATH: {
        Version.DEFAULT.value: {
            "Password": str,
            "PublicKey": str,
            "PrivateKey": str,
            "Passphrase": str,
            "UpdateSystem": bool,
        },
    },
    POST_MANAGED_SYSTEMS_ID_MANAGED_ACCOUNTS_CREDENTIALS_CHANGE: {
        Version.DEFAULT.value: {
            "Password": str,
            "UpdateSystem": bool,
            "Queue": bool,
        },
    },
}
