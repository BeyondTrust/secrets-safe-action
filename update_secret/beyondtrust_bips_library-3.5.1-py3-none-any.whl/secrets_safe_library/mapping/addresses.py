"""
This file contains the fields mapping for each endpoint and version related to
Addresses.

More info for the fields included in each endpoint and version:
- https://docs.beyondtrust.com/bips/docs/beyondinsight-api
"""

from secrets_safe_library.constants.endpoints import GET_ADDRESSES_ID, PUT_ADDRESSES_ID
from secrets_safe_library.constants.versions import Version

_address_fields = [
    "AddressID",
    "AddressGroupID",
    "Type",
    "Value",
    "Omit",
    "LastUpdateDate",
]

fields = {
    GET_ADDRESSES_ID: {
        Version.DEFAULT.value: _address_fields,
    },
    PUT_ADDRESSES_ID: {
        Version.DEFAULT.value: _address_fields,
    },
}
