"""
This file contains the fields mapping for each endpoint and version related to ISA
Sessions.

More info for the fields included in each endpoint and version:
- https://docs.beyondtrust.com/bips/docs/passwordsafe-api
"""

from secrets_safe_library.constants.endpoints import POST_ISA_SESSIONS
from secrets_safe_library.constants.versions import Version

fields = {
    POST_ISA_SESSIONS: {
        Version.DEFAULT.value: {
            "SystemID": int,
            "AccountID": int,
            "ApplicationID": int,
            "SessionType": str,
            "Record": bool,
            "DurationMinutes": int,
            "Resolution": str,
            "Reason": str,
            "NodeID": str,
            "SpanMultipleMonitors": bool,
        },
    }
}
