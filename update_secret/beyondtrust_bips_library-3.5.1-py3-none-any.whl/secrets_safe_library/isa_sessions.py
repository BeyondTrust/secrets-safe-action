"""ISA Sessions module, all the logic to manage ISA Sessions from PS API"""

import logging

from cerberus import Validator

from secrets_safe_library import exceptions, utils
from secrets_safe_library.authentication import Authentication
from secrets_safe_library.constants.endpoints import POST_ISA_SESSIONS
from secrets_safe_library.constants.versions import Version
from secrets_safe_library.core import APIObject
from secrets_safe_library.mapping.isa_sessions import fields as isa_sessions_fields


class ISASession(APIObject):

    def __init__(self, authentication: Authentication, logger: logging.Logger = None):
        super().__init__(authentication, logger, endpoint="/isasessions")

        self._schema = {
            "system_id": {"type": "integer", "nullable": False},
            "account_id": {"type": "integer", "nullable": False},
            "application_id": {"type": "integer", "nullable": True},
            "session_type": {"type": "string", "maxlength": 32, "nullable": True},
            "record": {"type": "boolean", "nullable": True},
            "duration_minutes": {"type": "integer", "nullable": True},
            "resolution": {"type": "string", "nullable": True},
            "node_id": {"type": "string", "nullable": True},
            "reason": {"type": "string", "maxlength": 256, "nullable": True},
            "span_multiple_monitors": {"type": "boolean", "nullable": True},
        }
        self._validator = Validator(self._schema)

    def create_isa_session(
        self,
        system_id: int,
        account_id: int,
        session_type: str = "SSH",
        node_id: str = None,
        reason: str = None,
        application_id: int = None,
        record: bool = None,
        duration_minutes: int = None,
        resolution: str = None,
        span_multiple_monitors: bool = None,
    ) -> dict:
        """
        Creates a new Information Systems Administrator (ISA) session for the given
        managed system and managed account.

        API: POST ISASessions

        Args:
            system_id (int): ID of the managed system to request.
            account_id (int): ID of the managed account to request.
            session_type (str, optional): The type of session to create. Defaults to
                "SSH". Options: SSH or sshticket, RDP or rdpticket, rdpfile, app, or
                appfile.
            node_id (str, optional): ID (GUID) of the node that should be used to
                establish the session. If NodeID is not given or if the Remote
                Session Proxy feature is disabled, uses the local node. Defaults
                to None.
            reason (str, optional): The reason for the request. Defaults to None.
            application_id (int, optional): ID of the application to launch. Required
                for the "app" and "appfile" session types. Defaults to None.
            record (bool, optional): Whether the session is recorded. When None, the
                API default applies. Defaults to None.
            duration_minutes (int, optional): The request duration in minutes. Defaults
                to None.
            resolution (str, optional): Screen resolution for RDP sessions, for
                example "1024x768" or "Maximized". Defaults to None.
            span_multiple_monitors (bool, optional): Whether an RDP session spans
                multiple monitors. Defaults to None.

        Returns:
            dict: The response from the API. For session types that return a file
                instead of JSON, such as "rdpfile" or "appfile", the dictionary
                holds the file and its metadata: {"FileName": str,
                "FileContent": str, "ContentType": str, "ContentEncoding": str}.
                FileContent is decoded text for text files and base64 for binary
                ones, as reported by ContentEncoding.
        """

        attributes = {
            "system_id": system_id,
            "account_id": account_id,
            "application_id": application_id,
            "session_type": session_type,
            "record": record,
            "duration_minutes": duration_minutes,
            "resolution": resolution,
            "node_id": node_id,
            "reason": reason,
            "span_multiple_monitors": span_multiple_monitors,
        }

        if not self._validator.validate(attributes, update=True):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        req_structure = self.get_request_body_version(
            isa_sessions_fields, POST_ISA_SESSIONS, Version.DEFAULT.value
        )

        req_body = self.generate_request_body(req_structure, **attributes)

        endpoint = self.endpoint

        utils.print_log(
            self._logger,
            "Calling create_isa_session endpoint",
            logging.DEBUG,
        )
        response = self._run_post_request(endpoint, req_body, include_api_version=False)

        return self._parse_json_or_file_response(response)
