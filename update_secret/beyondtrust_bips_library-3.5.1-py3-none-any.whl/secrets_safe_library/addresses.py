"""
Addresses module, all the logic to manage addresses from BeyondInsight API
"""

import logging

from cerberus import Validator

from secrets_safe_library import exceptions, utils
from secrets_safe_library.authentication import Authentication
from secrets_safe_library.core import APIObject
from secrets_safe_library.mixins import DeleteByIdMixin


class Address(APIObject, DeleteByIdMixin):

    def __init__(self, authentication: Authentication, logger: logging.Logger = None):
        super().__init__(authentication, logger, endpoint="/addresses")

        # Schema rules used for address validations
        self._schema = {
            "type": {
                "type": "string",
                "allowed": ["single", "range", "cidr", "name"],
                "nullable": False,
                "required": True,
            },
            "value": {
                "type": "string",
                "maxlength": 255,
                "nullable": False,
                "required": True,
            },
            "omit": {"type": "boolean", "nullable": True},
        }
        self._validator = Validator(self._schema)

    def get_address_by_id(self, address_id: int) -> dict:
        """
        Find an address by ID.

        API: GET Addresses/{id}

        Args:
            address_id (int): The address ID.

        Returns:
            dict: Address object.
        """

        endpoint = f"{self.endpoint}/{address_id}"

        utils.print_log(
            self._logger,
            "Calling get_address_by_id endpoint",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)

        return response.json()

    def update_address(
        self,
        address_id: int,
        address_type: str,
        value: str,
        omit: bool = False,
    ) -> dict:
        """
        Updates an address by ID.

        API: PUT Addresses/{id}

        Args:
            address_id (int): The address ID.
            address_type (str): Address type, one of "single", "range", "cidr" or
                "name".
            value (str): The address value (max 255 chars); format depends on the
                address type.
            omit (bool, optional): Whether to omit/exclude this address. Defaults to
                False.

        Returns:
            dict: Updated address object.
        """

        attributes = {
            "type": address_type,
            "value": value,
            "omit": omit,
        }

        if not self._validator.validate(attributes):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        payload = {
            "Type": address_type,
            "Value": value,
            "Omit": omit,
        }

        endpoint = f"{self.endpoint}/{address_id}"

        utils.print_log(
            self._logger,
            "Calling update_address endpoint",
            logging.DEBUG,
        )
        response = self._run_put_request(endpoint, payload)

        return response.json()
