"""Security module, includes sensitive data sanitization."""

import re

# Upper bound on the length of text that sanitization regexes are applied to.
# Log messages can embed untrusted, server-controlled response bodies of
# unbounded size; capping the input before running the regex patterns ensures
# the (already length-bounded) patterns always execute in bounded time and
# cannot be abused for a regex denial-of-service (ReDoS).
_MAX_SANITIZE_LENGTH = 65536

# Size of the tail window (in chars) scanned after truncation to detect
# sensitive-pattern openers that may straddle the truncation boundary. Sized to
# comfortably exceed the largest bounded pattern body (the 8192-char PEM body).
_TRUNCATION_TAIL_WINDOW = 8192

# Locates the start of sensitive-pattern openers within the tail window scanned
# after truncation. Each alternative is bounded and uses only simple character
# classes (no nested quantifiers, no ambiguous backtracking) so this scan is
# itself ReDoS-safe when run against the (already length-bounded) tail window.
# The value tails on assignment/Bearer/JWT/URL openers are capped so that a
# dangling opener anywhere in the tail is still located quickly.
_DANGLING_OPENER_RE = re.compile(
    r"(?ix)"
    r"("
    r"    -----BEGIN"  # PEM header
    r"  | Bearer[ \t]+[A-Za-z0-9+/=._-]{1,500}"  # Bearer token
    r"  | https?://[^:/@\s]{1,512}:[^@\s]{1,512}"  # URL creds (no closing @)
    r"  | eyJ[A-Za-z0-9+/=._-]{20,500}"  # JWT prefix
    r"  | \b(?:api_?key|access_?token|client_secret|client_key"
    r"      |authorization|password|passwd|pwd|secret|token|key)"
    r"    [\"']?\s*[:=]\s*[\"']?[^\s\"'<>&;,]{0,500}"  # sensitive assignment
    r")"
)


def _is_dangling(opener: str, prefix: str, opener_end: int) -> bool:
    """Return True if ``opener`` in the retained ``prefix`` has no closer.

    ``opener_end`` is the position immediately after the matched opener; a
    closer for that opener kind must appear at or after that position within
    the retained prefix, otherwise the opener is considered "dangling" (the
    closing delimiter was almost certainly cut off by truncation).
    """

    rest = prefix[opener_end:]
    lower = opener.lower()

    if opener.startswith("-----BEGIN"):
        return "-----END" not in rest
    if lower.startswith("bearer"):
        # A Bearer token is terminated by whitespace; no whitespace anywhere
        # after the opener means the token continues past the truncation.
        return not any(ch.isspace() for ch in rest)
    if lower.startswith(("http://", "https://")):
        # URL credentials require a closing ``@`` for the redaction regex to
        # match. Absence of ``@`` in the remainder means the userinfo was cut.
        return "@" not in rest
    if opener.startswith("eyJ"):
        # JWT tokens are typically terminated by whitespace or a non-token
        # character. If none of these follow, the token was truncated mid-body.
        return not re.search(r"[\s\"',;<>]", rest)
    # Assignment-style openers: value continues to end without a closing quote
    # or delimiter -> dangling.
    return not re.search(r"[\s\"'<>&;,]", rest)


def _safe_truncate(message: str) -> str:
    """Truncate ``message`` to ``_MAX_SANITIZE_LENGTH`` without leaking secrets.

    Slicing a message at an arbitrary byte offset can leak partial secrets when
    a sensitive value straddles the truncation boundary — the redaction regexes
    require a closer (matching quote, ``-----END``, ``@``, etc.) which may have
    been cut off. This helper detects such dangling openers in the retained
    prefix's tail and trims / replaces the tail so partial secrets are not
    returned. A ``[TRUNCATED]`` marker is appended to signal the cut.
    """

    prefix = message[:_MAX_SANITIZE_LENGTH]
    tail_start = max(0, len(prefix) - _TRUNCATION_TAIL_WINDOW)
    tail = prefix[tail_start:]

    for match in _DANGLING_OPENER_RE.finditer(tail):
        opener_start = tail_start + match.start()
        opener_end = tail_start + match.end()
        if _is_dangling(match.group(1), prefix, opener_end):
            prefix = prefix[:opener_start] + "***REDACTED_TRUNCATED***"
            break

    return prefix + "[TRUNCATED]"


def sanitize_sensitive_data(message: str) -> str:
    """
    Sanitize sensitive information from log messages.

    Arguments:
        message (str): The original log message

    Returns:
        str: Sanitized log message with sensitive data redacted
    """

    if not isinstance(message, str):
        message = str(message)

    # Bound the amount of (potentially untrusted) text the regexes process so
    # the sanitization step always runs in bounded time regardless of how large
    # the original message is. Truncation is boundary-safe: dangling openers of
    # sensitive patterns at the tail are trimmed / redacted to avoid leaking
    # partial secrets that would otherwise no longer match the redaction regex.
    if len(message) > _MAX_SANITIZE_LENGTH:
        message = _safe_truncate(message)

    # Define sensitive data patterns

    # Compile regex patterns once at module initialization
    _COMPILED_PATTERNS = [
        (
            re.compile(
                r'("?api_?key"?\s*[:=]\s*["\']?)([a-zA-Z0-9+/=_-]{20,200})(["\']?)'
            ),
            r"\1***REDACTED***\3",
        ),
        (
            re.compile(r'("?key"?\s*[:=]\s*["\']?)([a-zA-Z0-9+/=_-]{20,200})(["\']?)'),
            r"\1***REDACTED***\3",
        ),
        (
            re.compile(r'("?password"?\s*[:=]\s*["\'])([^"\']+)(["\'])'),
            r"\1***REDACTED***\3",
        ),
        (
            re.compile(r'("?password"?\s*[:=]\s*)([^\s;&,"\']+)(?=[\s;&,]|$)'),
            r"\1***REDACTED***",
        ),
        (
            re.compile(r'("?pwd"?\s*[:=]\s*["\'])([^"\']+)(["\'])'),
            r"\1***REDACTED***\3",
        ),
        (
            re.compile(r'("?pwd"?\s*[:=]\s*)([^\s;&,"\']+)(?=[\s;&,]|$)'),
            r"\1***REDACTED***",
        ),
        (
            re.compile(r'("?passwd"?\s*[:=]\s*["\'])([^"\']+)(["\'])'),
            r"\1***REDACTED***\3",
        ),
        (
            re.compile(r'("?passwd"?\s*[:=]\s*)([^\s;&,"\']+)(?=[\s;&,]|$)'),
            r"\1***REDACTED***",
        ),
        (
            re.compile(
                r'("?client_?secret"?\s*[:=]\s*["\']?)'
                r'([a-zA-Z0-9+/=_-]{20,200})(["\']?)'
            ),
            r"\1***REDACTED***\3",
        ),
        (
            re.compile(
                r'("?secret"?\s*[:=]\s*["\']?)([a-zA-Z0-9+/=_-]{20,200})(["\']?)'
            ),
            r"\1***REDACTED***\3",
        ),
        (re.compile(r"(Bearer\s+)([a-zA-Z0-9+/=._-]{20,500})"), r"\1***REDACTED***"),
        (
            re.compile(
                r'("?token"?\s*[:=]\s*["\']?)([a-zA-Z0-9+/=._-]{20,500})(["\']?)'
            ),
            r"\1***REDACTED***\3",
        ),
        (
            re.compile(
                r'("?access_?token"?\s*[:=]\s*["\']?)'
                r'([a-zA-Z0-9+/=._-]{20,500})(["\']?)'
            ),
            r"\1***REDACTED***\3",
        ),
        (
            re.compile(
                r'(Authorization["\']?\s*[:=]\s*["\']?)([^"\'\\n\\r]{10,500})(["\']?)'
            ),
            r"\1***REDACTED***\3",
        ),
        (
            # Body and segments are length-bounded so the lazy/greedy quantifiers
            # cannot backtrack quadratically over untrusted, attacker-controlled
            # input (ReDoS protection). The caps comfortably cover real PEM blocks
            # and URL userinfo while keeping matching linear in the input size.
            # The URL tail group ``@[^\s]+`` is safe unbounded because ``[^\s]``
            # is a simple character-class negation with a single ``+`` — there is
            # no catastrophic-backtracking potential — and the overall input is
            # already bounded by ``_MAX_SANITIZE_LENGTH``.
            re.compile(
                r"(-----BEGIN[^-]*-----)(.{0,8192}?)(-----END[^-]*-----)", re.DOTALL
            ),
            r"\1***REDACTED***\3",
        ),
        (
            re.compile(r"(https?://)([^:/@]{1,512}):([^@]{1,512})(@[^\s]+)"),
            r"\1\2:***REDACTED***\4",
        ),
        (re.compile(r"(eyJ[a-zA-Z0-9+/=._-]{20,})"), r"***REDACTED_JWT***"),
        (re.compile(r'(["\'][a-zA-Z0-9+/=]{40,}["\'])'), r"***REDACTED***"),
    ]

    # Apply sanitization patterns
    sanitized_message = message
    for cregex, replacement in _COMPILED_PATTERNS:
        sanitized_message = cregex.sub(replacement, sanitized_message)

    # Additional keyword-based sanitization for common sensitive field names
    # Note: Skip keywords already handled by main patterns to avoid double-processing
    sensitive_keywords = [
        "password",
        "passwd",
        "pwd",
        "secret",
        "token",
        "key",
        "api_key",
        "apikey",
        "client_secret",
        "client_key",
        "private_key",
        "certificate",
        "cert",
        "credential",
        "auth",
        "authorization",
        "access_token",
        "refresh_token",
    ]

    # Look for patterns like "field": "value" or field=value where field is sensitive
    for keyword in sensitive_keywords:
        # JSON-style assignments
        pattern = rf'("{keyword}"\s*:\s*")([^"]+)(")'
        sanitized_message = re.sub(
            pattern, r"\1***REDACTED***\3", sanitized_message, flags=re.IGNORECASE
        )

        # Form-style assignments for unquoted values
        # Use word boundaries and more specific delimiters
        pattern = rf'\b({keyword}\s*=\s*)([^\s;&,"\']+)(?=[\s;&,]|$)'
        sanitized_message = re.sub(
            pattern, r"\1***REDACTED***", sanitized_message, flags=re.IGNORECASE
        )

        # Form-style assignments for quoted values (single and double quotes)
        pattern = rf'\b({keyword}\s*=\s*")([^"]*?)(")'
        sanitized_message = re.sub(
            pattern, r"\1***REDACTED***\3", sanitized_message, flags=re.IGNORECASE
        )

        pattern = rf"\b({keyword}\s*=\s*')([^']*?)(')"
        sanitized_message = re.sub(
            pattern, r"\1***REDACTED***\3", sanitized_message, flags=re.IGNORECASE
        )

    return sanitized_message
