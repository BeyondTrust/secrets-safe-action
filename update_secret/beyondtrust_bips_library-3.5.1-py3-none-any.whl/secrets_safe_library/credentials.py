"""Credentials module, all the logic to manage Credentials from Password Safe API"""

import logging
from urllib.parse import quote

from secrets_safe_library import exceptions, utils
from secrets_safe_library.authentication import Authentication
from secrets_safe_library.constants.endpoints import (
    POST_MANAGED_SYSTEMS_ID_MANAGED_ACCOUNTS_CREDENTIALS_CHANGE,
    PUT_CREDENTIALS_BY_NAMES,
    PUT_CREDENTIALS_BY_PATH,
)
from secrets_safe_library.constants.versions import Version
from secrets_safe_library.core import APIObject
from secrets_safe_library.mapping.credentials import fields as credentials_fields


class Credentials(APIObject):

    def __init__(self, authentication: Authentication, logger: logging.Logger = None):
        super().__init__(authentication, logger, endpoint="/credentials")

        # Schema rules used for validations
        self._schema = {
            "request_id": {"type": "integer", "nullable": True},
            "alias_id": {"type": "integer", "nullable": True},
            "managed_account_id": {"type": "integer", "nullable": True},
            "type": {
                "type": "string",
                "allowed": ["password", "dsskey", "totp"],
                "nullable": True,
            },
            "password": {"type": "string", "nullable": True},
            "public_key": {"type": "string", "nullable": True},
            "private_key": {"type": "string", "nullable": True},
            "passphrase": {"type": "string", "nullable": True},
            "update_system": {"type": "boolean", "nullable": True},
            "queue": {"type": "boolean", "nullable": True},
            "workgroup_name": {
                "type": "string",
                "required": True,
                "empty": False,
            },
            "asset_name": {"type": "string", "required": True, "empty": False},
            "account_name": {"type": "string", "required": True, "empty": False},
            "system_id": {"type": "integer", "required": True, "min": 1},
        }
        self._validator = utils.Validator(self._schema)

    def get_credentials_by_request_id(self, request_id: int, type: str = None) -> dict:
        """
        Returns credentials by request ID.

        API: GET Credentials/{requestid}

        Args:
            request_id (int): The request ID.
            type (str, optional): The type of credentials to return. Options are:
                - password (default): Returns the password in the response body.
                - dsskey: Returns the DSS private key in the response body.
        Returns:
            dict: Credentials.
        """

        attributes = {"request_id": request_id, "type": type}

        if not self._validator.validate(attributes, update=True):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        params = {"type": type}

        query_string = self.make_query_string(params)

        endpoint = f"{self.endpoint}/{request_id}?{query_string}"

        utils.print_log(
            self._logger,
            "Calling get_credentials_by_request_id endpoint",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)

        return response.json()

    def get_credentials_by_alias_id(
        self, alias_id: int, request_id: int, type: str = None
    ) -> dict:
        """
        Returns credentials by alias ID.

        API: GET Aliases/{aliasId}/Credentials/{requestId}

        Args:
            alias_id (int): The alias ID.
            request_id (int): The request ID.
            type (str, optional): The type of credentials to return. Options are:
                - password (default): Returns the password in the response body.
                - dsskey: Returns the DSS private key in the response body.
        Returns:
            dict: Credentials.
        """

        attributes = {"alias_id": alias_id, "request_id": request_id, "type": type}

        if not self._validator.validate(attributes, update=True):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        params = {"type": type}

        query_string = self.make_query_string(params)

        endpoint = f"/aliases/{alias_id}/credentials/{request_id}?{query_string}"

        utils.print_log(
            self._logger,
            "Calling get_credentials_by_alias_id endpoint",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)

        return response.json()

    def get_credentials_by_managed_account_id(
        self, managed_account_id: int, type: str = "totp"
    ) -> dict:
        """
        Returns credentials by managed account ID.

        API: GET ManagedAccounts/{managedAccountId}/Credentials

        Args:
            managed_account_id (int): The managed account ID.
            type (str, optional): The type of credentials to return. Options are:
                - totp (default): Returns the TOTP code in the response body.
                - password: Returns the password in the response body.
                - dsskey: Returns the DSS private key in the response body.
        Returns:
            dict: Credentials.
        """

        attributes = {"managed_account_id": managed_account_id, "type": type}

        if not self._validator.validate(attributes, update=True):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        params = {"type": type}

        query_string = self.make_query_string(params)

        endpoint = f"/managedaccounts/{managed_account_id}/credentials?{query_string}"

        utils.print_log(
            self._logger,
            "Calling get_credentials_by_managed_account_id endpoint",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)

        return response.json()

    def update_credentials_by_names(
        self,
        workgroup_name: str,
        asset_name: str,
        account_name: str,
        private_key: str = None,
        public_key: str = None,
        password: str = None,
        passphrase: str = None,
        update_system: bool = True,
    ) -> None:
        """
        Updates the credentials of a managed account using workgroup, asset, and
        account names, optionally applying the change to the managed system.

        API: PUT Credentials?workgroupName={workgroupName}&assetName={assetName}
             &accountName={accountName}

        Args:
            workgroup_name (str): Name of the workgroup.
            asset_name (str): Name of the asset.
            account_name (str): Name of the managed account.
            private_key (str, optional): New private key for the managed account.
            public_key (str, optional): Required if private_key is provided and
                                        update_system is True.
                                        The new public key to set on the host.
            password (str, optional): New password for the managed account. If not
                                      given, generates a new random password.
            passphrase (str, optional): New passphrase for the private key.
            update_system (bool): True to update the system with new credentials,
                                  otherwise False. Defaults to True.
        Returns:
            None.

        Raises:
            exceptions.OptionsError: If the provided attributes do not pass validation.
        """

        attributes = {
            "workgroup_name": workgroup_name,
            "asset_name": asset_name,
            "account_name": account_name,
            "password": password,
            "public_key": public_key,
            "private_key": private_key,
            "passphrase": passphrase,
            "update_system": update_system,
        }

        if not self._validator.validate(attributes, update=True):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        if private_key and update_system and not public_key:
            raise exceptions.OptionsError(
                "public_key is required when private_key is provided and "
                "update_system is True."
            )

        req_structure = self.get_request_body_version(
            credentials_fields,
            PUT_CREDENTIALS_BY_NAMES,
            Version.DEFAULT.value,
        )

        req_body = self.generate_request_body(req_structure, **attributes)

        params = {
            "workgroupName": workgroup_name,
            "assetName": asset_name,
            "accountName": account_name,
        }
        query_string = self.make_query_string(params)

        endpoint = f"{self.endpoint}?{query_string}"
        utils.print_log(
            self._logger,
            "Calling update_credentials_by_names endpoint",
            logging.DEBUG,
        )
        self._run_put_request(
            endpoint,
            req_body,
            include_api_version=False,
            expected_status_code=204,
        )
        utils.print_log(
            self._logger,
            "Credentials updated successfully by names",
            logging.INFO,
        )

    def update_credentials_by_path(
        self,
        workgroup_name: str,
        asset_name: str,
        account_name: str,
        private_key: str = None,
        public_key: str = None,
        password: str = None,
        passphrase: str = None,
        update_system: bool = True,
    ) -> None:
        """
        Updates the credentials of a managed account using the fully qualified path,
        optionally applying the change to the managed system.

        API: PUT Workgroups/{workgroupName}/Assets/{assetName}/ManagedSystems/
             ManagedAccounts/{accountName}/Credentials

        Args:
            workgroup_name (str): Name of the workgroup.
            asset_name (str): Name of the asset.
            account_name (str): Name of the managed account.
            private_key (str, optional): New private key for the managed account.
            public_key (str, optional): Required if private_key is provided and
                                        update_system is True.
                                        The new public key to set on the host.
            password (str, optional): New password for the managed account. If not
                                      given, generates a new random password.
            passphrase (str, optional): New passphrase for the private key.
            update_system (bool): True to update the system with new credentials,
                                  otherwise False. Defaults to True.
        Returns:
            None.

        Raises:
            exceptions.OptionsError: If the provided attributes do not pass validation.
        """

        attributes = {
            "workgroup_name": workgroup_name,
            "asset_name": asset_name,
            "account_name": account_name,
            "password": password,
            "public_key": public_key,
            "private_key": private_key,
            "passphrase": passphrase,
            "update_system": update_system,
        }

        if not self._validator.validate(attributes, update=True):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        if private_key and update_system and not public_key:
            raise exceptions.OptionsError(
                "public_key is required when private_key is provided and "
                "update_system is True."
            )

        req_structure = self.get_request_body_version(
            credentials_fields,
            PUT_CREDENTIALS_BY_PATH,
            Version.DEFAULT.value,
        )

        req_body = self.generate_request_body(req_structure, **attributes)

        endpoint = (
            f"/workgroups/{quote(workgroup_name, safe='')}/"
            f"assets/{quote(asset_name, safe='')}/"
            f"managedsystems/managedaccounts/"
            f"{quote(account_name, safe='')}/credentials"
        )
        utils.print_log(
            self._logger,
            "Calling update_credentials_by_path endpoint",
            logging.DEBUG,
        )
        self._run_put_request(
            endpoint,
            req_body,
            include_api_version=False,
            expected_status_code=204,
        )
        utils.print_log(
            self._logger,
            "Credentials updated successfully by path",
            logging.INFO,
        )

    def change_all_credentials_on_system(
        self,
        system_id: int,
        *,
        update_system: bool = True,
        queue: bool = False,
        password: str = None,
    ) -> None:
        """
        Forces a password change on all managed accounts for a given managed system.

        API: POST ManagedSystems/{systemId}/ManagedAccounts/Credentials/Change

        Args:
            system_id (int): ID of the managed system.
            update_system (bool): True to apply the new credentials to the target
                system, otherwise False. Defaults to True.
            queue (bool): True to queue the change if the target system is
                unreachable, otherwise the operation fails immediately.
                Defaults to False.
            password (str, optional): New password to set. If not provided, a new
                random password is auto-generated.

        Returns:
            None

        Raises:
            exceptions.OptionsError: If the provided attributes do not pass validation.
        """

        attributes = {
            "system_id": system_id,
            "password": password,
            "update_system": update_system,
            "queue": queue,
        }

        if not self._validator.validate(attributes, update=True):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        req_structure = self.get_request_body_version(
            credentials_fields,
            POST_MANAGED_SYSTEMS_ID_MANAGED_ACCOUNTS_CREDENTIALS_CHANGE,
            Version.DEFAULT.value,
        )

        req_body = self.generate_request_body(req_structure, **attributes)

        endpoint = f"/managedsystems/{system_id}/managedaccounts/credentials/change"
        utils.print_log(
            self._logger,
            "Calling change_all_credentials_on_system endpoint",
            logging.DEBUG,
        )
        self._run_post_request(
            endpoint,
            payload=req_body,
            expected_status_code=[204],
            include_api_version=True,
        )
        utils.print_log(
            self._logger,
            "All managed account credentials changed successfully on system",
            logging.INFO,
        )
