"""Logger class, used for logging messages."""

# -*- coding: utf-8 -*-
# (c) 2025 BeyondTrust Inc.
# GNU General Public License v3.0+
# (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
import logging
import os
import stat
from logging.handlers import RotatingFileHandler


def _secure_open_flags_opener(path, flags):
    # Refuse to follow a symlink at the target path. An attacker with write
    # access to the log directory could otherwise plant a symlink pointing
    # at a file the process can write to (or swap one in via a TOCTOU
    # race), redirecting sensitive diagnostic output to an unintended
    # target. O_NOFOLLOW causes os.open to raise OSError(ELOOP) when the
    # final path component is a symlink. Guard on hasattr since Windows
    # lacks O_NOFOLLOW; the platform does not support this semantic anyway.
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    # Add O_NONBLOCK so a FIFO planted at the target path does not cause
    # the open to hang. Opening a FIFO for write without O_NONBLOCK blocks
    # until a reader attaches; with O_NONBLOCK it returns immediately with
    # ENXIO if no reader is present, which surfaces cleanly as an OSError
    # instead of a stalled handler. O_NONBLOCK is a no-op on regular files
    # on Linux, so no follow-up fcntl to clear the flag is needed for the
    # intended regular-file case.
    if hasattr(os, "O_NONBLOCK"):
        flags |= os.O_NONBLOCK
    return os.open(path, flags, 0o600)


class _SecureRotatingFileHandler(RotatingFileHandler):
    """RotatingFileHandler that restricts log files to owner-only access.

    Diagnostic logs may contain API endpoints and error response bodies that
    must not be exposed to other local users on a shared Ansible control node.
    Log files (including rotated backups) are created with mode 0600 instead of
    relying on the process umask, which commonly yields world-readable 0644.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # RotatingFileHandler assigns self.backupCount after its __init__
        # calls _open(), so the first _open() cannot see it. Re-tighten any
        # pre-existing rotated backups here now that backupCount is known.
        self._tighten_rotated_backups()

    def _tighten_rotated_backups(self):
        # Best-effort tighten pre-existing rotated backups (e.g. foo.log.1..N)
        # that may have been created before this handler was in place. New
        # rotations inherit permissions via rename() so future rollovers are
        # safe automatically.
        #
        # On a shared control node an attacker with write access to the log
        # directory could pre-plant a symlink at {baseFilename}.N pointing at
        # an unrelated file the process can chmod. A path-based os.chmod would
        # follow that symlink and tighten permissions on the target, so we
        # must never resolve the rotation path through a symlink. Precedence:
        #
        #   1. Primary (POSIX with O_NOFOLLOW + fchmod, i.e. Linux/macOS/
        #      *BSD): open the path with O_NOFOLLOW, which raises OSError
        #      (errno.ELOOP) if the final component is a symlink -- the
        #      kernel refuses to follow it. Then fchmod(fd, 0o600) tightens
        #      the mode on the specific inode bound at open() time, so no
        #      subsequent symlink swap can redirect the chmod to another
        #      file. This closes the TOCTOU window entirely.
        #
        #   2. Fallback (platforms lacking O_NOFOLLOW or fchmod, e.g.
        #      Windows): if os.chmod supports follow_symlinks=False, use
        #      that -- it closes the race atomically at the kernel level.
        #      Otherwise skip the file: a path-based os.chmod would follow
        #      a symlink swapped in after any lstat guard and let an
        #      attacker redirect the chmod to a file of their choosing.
        #      _tighten_rotated_backups is best-effort by design, so
        #      skipping preserves that contract safely; the file retains
        #      whatever mode it already had, which is no worse than the
        #      pre-fix behavior for pre-existing backups. New rotations
        #      produced by this handler inherit tight permissions via
        #      rename() and are unaffected.
        #
        # Decide the strategy once, then dispatch per rotation slot.
        if hasattr(os, "O_NOFOLLOW") and hasattr(os, "fchmod"):
            tighten = self._tighten_backup_fd
        else:
            tighten = self._tighten_backup_fallback
        for i in range(1, getattr(self, "backupCount", 0) + 1):
            tighten(f"{self.baseFilename}.{i}")

    @staticmethod
    def _tighten_backup_fd(backup):
        # Primary POSIX path: race-free via O_NOFOLLOW + fchmod.
        # O_NOFOLLOW raises ELOOP if `backup` is a symlink; other
        # errors (ENOENT for a missing slot, EACCES for an
        # unreadable parent, etc.) are also best-effort skipped.
        #
        # Add O_NONBLOCK so opening a FIFO planted at {baseFilename}.N
        # does not block. Per POSIX, opening a FIFO O_RDONLY without
        # O_NONBLOCK blocks until a writer opens the other end, which
        # would hang the handler's constructor. With O_NONBLOCK the
        # open returns immediately; the S_ISREG check below then
        # rejects the FIFO. O_NONBLOCK is a no-op on regular files
        # on Linux, so it is safe for the intended case.
        open_flags = os.O_RDONLY | os.O_NOFOLLOW
        if hasattr(os, "O_NONBLOCK"):
            open_flags |= os.O_NONBLOCK
        try:
            fd = os.open(backup, open_flags)
        except OSError:
            return
        try:
            # Verify the fd refers to a regular file before chmodding.
            # An attacker with write access to the log directory could
            # plant a directory, FIFO, or device file at {baseFilename}.N
            # (not just a symlink); O_NOFOLLOW only refuses symlinks, so
            # we still need to reject other non-regular types here to
            # avoid chmodding an unintended object.
            try:
                st = os.fstat(fd)
            except OSError:
                # Best-effort: rare fstat failure. Skip via finally.
                return
            if not stat.S_ISREG(st.st_mode):
                return
            try:
                os.fchmod(fd, 0o600)
            except OSError:
                # Best-effort: e.g. file owned by another user.
                pass
        finally:
            os.close(fd)

    @staticmethod
    def _tighten_backup_fallback(backup):
        # Fallback path: no O_NOFOLLOW/fchmod available.
        try:
            st = os.lstat(backup)
        except OSError:
            # Missing rotation slot or unreadable parent: best-effort.
            return
        # Never chmod through a symlink; the target may be an unrelated
        # file (config, another user's data) that we must not touch.
        if stat.S_ISLNK(st.st_mode):
            return
        # Only chmod regular files. A pre-planted directory, FIFO, or
        # device file at the rotation slot must not be chmodded. Reuse
        # the mode returned by lstat() above to avoid an extra syscall.
        if not stat.S_ISREG(st.st_mode):
            return
        if os.chmod not in os.supports_follow_symlinks:
            # Fallback branch: a path-based os.chmod would be vulnerable
            # to a TOCTOU symlink swap between the lstat() above and the
            # chmod call. Skip rather than risk chmodding an arbitrary
            # target; this preserves the best-effort contract safely.
            return
        try:
            os.chmod(backup, 0o600, follow_symlinks=False)
        except OSError:
            pass

    def _open(self):
        stream = open(
            self.baseFilename,
            self.mode,
            encoding=self.encoding,
            errors=getattr(self, "errors", None),
            opener=_secure_open_flags_opener,
        )
        # Tighten permissions on files that may already exist with a looser
        # mode, since the open mode argument only applies on creation. Use
        # fchmod on the open file descriptor rather than a path-based chmod
        # to avoid a TOCTOU race between open() and chmod().
        try:
            if hasattr(os, "fchmod"):
                os.fchmod(stream.fileno(), 0o600)
        except OSError:
            # fchmod may legitimately fail (e.g. file owned by another user).
            # The fstat check below is the source of truth and will fail loudly
            # if the file is not actually 0600.
            pass

        # Best-effort tighten pre-existing rotated backups. On the initial
        # _open() call from RotatingFileHandler.__init__, self.backupCount
        # has not yet been assigned (getattr defaults to 0 and this loop is
        # a no-op); __init__ re-invokes _tighten_rotated_backups after super
        # init to cover that case. On subsequent _open() calls (e.g. after
        # doRollover) backupCount is set and this loop tightens any strays.
        self._tighten_rotated_backups()

        self._verify_stream_or_close(stream)
        return stream

    def _verify_stream_or_close(self, stream):
        # Verify the effective permissions on the open file descriptor. If
        # the mode is not exactly 0600, refuse to write potentially sensitive
        # diagnostic data (API endpoints, error bodies) to it. Using fstat on
        # the fd avoids any path-based race between open() and stat(). Ensure
        # the stream is closed on any error path (including os.fstat failing)
        # so we do not leak the underlying file descriptor.
        #
        # Only enforce on platforms with POSIX permission semantics. When
        # os.fchmod is unavailable (e.g. Windows), st_mode does not represent
        # POSIX 0600 in a comparable form, so the check would produce a
        # misleading RuntimeError. Ansible control nodes are POSIX in
        # practice; this guard just avoids a confusing failure on non-POSIX.
        if not hasattr(os, "fchmod"):
            return
        try:
            st = os.fstat(stream.fileno())
            # A FIFO, character/block device, directory, or socket at
            # self.baseFilename could satisfy the 0o600 mode check yet
            # still redirect sensitive log data to the wrong place.
            # O_NOFOLLOW in the opener already refuses symlinks, but
            # other non-regular file types are not covered by it.
            if not stat.S_ISREG(st.st_mode):
                file_type = stat.S_IFMT(st.st_mode)
                raise RuntimeError(
                    f"Refusing to use log file {self.baseFilename!r}: "
                    f"path is not a regular file "
                    f"(st_mode file type={file_type:#o})."
                )
            # Compare against S_IMODE (permission bits + setuid/setgid/
            # sticky) rather than a bare 0o777 mask so a file like 1600
            # (sticky) or 4600 (setuid) does NOT pass this check. The PR
            # goal is strict 0600.
            actual_mode = stat.S_IMODE(st.st_mode)
            if actual_mode != 0o600:
                raise RuntimeError(
                    f"Refusing to use log file {self.baseFilename!r}: "
                    f"permissions are {actual_mode:04o}, expected 0600."
                )
        except Exception:
            stream.close()
            raise


class Logger:
    """
    Logger class, used to define a logger instance.
    """

    def __init__(self, log_level: int, log_file_name: str) -> None:
        """
        Initialize a new Logger instance.

        Args:
            log_level (int): Logging level.
            log_file_name (str): Name of the log file.
        """
        self.logger = logging.getLogger(log_file_name)
        self.logger.setLevel(log_level)

        if not self.logger.handlers:
            handler = _SecureRotatingFileHandler(
                f"{log_file_name}.log",
                maxBytes=1_000_000,
                backupCount=5,
                encoding="utf-8",
            )
            formatter = logging.Formatter(
                "%(asctime)-5s %(name)-15s %(levelname)-8s %(message)s"
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)

        return
