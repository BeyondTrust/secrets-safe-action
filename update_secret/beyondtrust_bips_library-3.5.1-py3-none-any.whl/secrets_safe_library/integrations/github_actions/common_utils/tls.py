"""TLS certificate verification settings for the GitHub Actions integrations."""

# Tokens that explicitly enable / disable TLS certificate verification.
VERIFY_CA_TRUE_TOKENS = frozenset({"true", "1", "yes", "on", "enable", "enabled"})
VERIFY_CA_FALSE_TOKENS = frozenset({"false", "0", "no", "off", "disable", "disabled"})


def parse_verify_ca(value: str | None) -> bool:
    """
    Parse a VERIFY_CA setting into a boolean.

    Only boolean values are accepted: a true token (true/1/yes/on/enable/
    enabled) or a false token (false/0/no/off/disable/disabled),
    case-insensitive. Unset or empty means True. Anything else, including a
    path to a CA bundle, raises rather than silently ignoring the caller's
    intent.

    Note that True verifies against the CA store the requests library defaults
    to (certifi's bundled roots), which is *not* the operating system trust
    store.

    Arguments:
        value (str | None): Raw VERIFY_CA value, None when unset.

    Returns:
        bool: True to verify certificates, False to disable verification.

    Raises:
        EnvironmentError: If the value is not a recognized true or false token.
    """

    if value is None:
        return True

    token = value.strip().lower()

    if not token or token in VERIFY_CA_TRUE_TOKENS:
        return True

    if token in VERIFY_CA_FALSE_TOKENS:
        return False

    raise EnvironmentError(
        f"Invalid value for VERIFY_CA: {value!r}. Use 'true' or 'false'."
    )
