"""Masking and step outputs for the GitHub Actions integrations."""

import os
import re
import uuid

COMMAND_MARKER = "::"


def escape_data(value: str) -> str:
    """
    Escape a value for safe use as a GitHub Actions workflow-command payload.

    Mirrors the escaping performed by the official @actions/core toolkit, so the
    payload cannot add runner-visible lines or start a new workflow command.

    Arguments:
        value (str): The raw value to escape.

    Returns:
        str: The escaped value with '%', CR, and LF percent-encoded.
    """

    return value.replace("%", "%25").replace("\r", "%0D").replace("\n", "%0A")


def mask_secret(value: str) -> None:
    """
    Register a value with the runner so it is masked in the workflow logs.

    Each line is masked separately, so a multi-line secret is masked line by
    line. The value is split on every line terminator the runner recognizes
    (CRLF, CR, LF) and each line is escaped, so a value containing a bare CR
    cannot inject extra workflow commands. Blank lines are skipped.

    The "::add-mask ::" form (with a space before the second marker) is
    intentional: the runner accepts it as add-mask with no properties.

    Arguments:
        value (str): The value to mask.

    Returns:
        None
    """

    for line in re.split(r"\r\n|\r|\n", value):
        if line.strip() != "":
            print(f"{COMMAND_MARKER}add-mask {COMMAND_MARKER}{escape_data(line)}")


def append_output(name: str, value: str) -> None:
    """
    Append a named value to the GitHub Actions step output file.

    The value is written as a heredoc with a random delimiter, so a multi-line
    value cannot end the entry early or add another output.

    Arguments:
        name (str): The name of the output. Callers must validate a name that
            comes from user input.
        value (str): The content to be written as the output.

    Returns:
        None
    """

    with open(os.environ["GITHUB_OUTPUT"], "a") as fh:
        delimiter = uuid.uuid4()
        print(f"{name}<<{delimiter}", file=fh)
        print(value, file=fh)
        print(delimiter, file=fh)
