import logging
import os
import pathlib
import sys

from github_action_utils import error

from secrets_safe_library import utils
from secrets_safe_library.security import sanitize_sensitive_data

# GitHub Actions error annotation positioning constants
ERROR_MESSAGE_COL = 1  # Starting column position for error annotation
ERROR_MESSAGE_END_COLUMN = 2  # Ending column position for error annotation
ERROR_MESSAGE_LINE = 4  # Starting line number for error annotation
ERROR_MESSAGE_END_LINE = 5  # Ending line number for error annotation


def show_error(error_message: str, logger: logging.Logger) -> None:
    """
    Displays an error message in the logs and prints an error message in the
    GitHub Actions shell.

    Arguments:
        error_message (str): The message to display as an error.
        logger (logging.Logger): Logger object for logging.

    Returns:
        None
    """

    error(
        sanitize_sensitive_data(error_message),
        title="Action Failed",
        col=ERROR_MESSAGE_COL,
        end_column=ERROR_MESSAGE_END_COLUMN,
        line=ERROR_MESSAGE_LINE,
        end_line=ERROR_MESSAGE_END_LINE,
    )
    utils.print_log(logger, error_message, logging.ERROR)
    sys.exit(1)


def _resolve_within_base_dir(file_name: str, base_dir: str) -> str:
    """
    Resolve ``file_name`` relative to ``base_dir`` and raise ``ValueError`` if
    the resolved path escapes the base directory (path traversal guard).
    """
    base = pathlib.Path(base_dir).resolve()
    resolved = (base / file_name).resolve()
    try:
        resolved.relative_to(base)
    except ValueError:
        raise ValueError(
            f"Path traversal detected: {file_name!r} escapes base directory"
        )
    return str(resolved)


def _open_secure_fd(file_name: str) -> int:
    """
    Atomically create ``file_name`` with owner-only permissions and return the
    file descriptor. ``O_EXCL`` refuses to reuse an existing inode (defeats
    race-before-unlink attacks) and ``O_NOFOLLOW`` refuses to follow symlinks
    (defeats symlink attacks that would redirect the write to an
    attacker-controlled path).
    """
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    fd = os.open(file_name, flags, 0o600)
    try:
        # Defense in depth: tighten permissions via the fd (fchmod is not
        # path-based, so it cannot be raced by a rename/replace of the path).
        if hasattr(os, "fchmod"):
            os.fchmod(fd, 0o600)
    except Exception:
        os.close(fd)
        raise
    return fd


def create_file(
    file_name: str, content: str, logger: logging.Logger, base_dir: str | None = None
) -> None:
    """
    Creates a file at the specified path and writes the provided content.

    The file is created with owner-only permissions (``0o600``) regardless of
    the ambient umask so that secret material is never world- or group-readable
    on multi-tenant CI runners.

    Implementation note (differs from ``open(file_name, "w")``): if a file
    already exists at ``file_name``, it is first ``unlink``ed so the write
    lands on a freshly created inode via ``O_CREAT | O_EXCL`` (with
    ``O_NOFOLLOW`` when the OS supports it). This avoids reusing a
    pre-existing loose-permission inode and rejects attacker-planted symlinks.
    Two consequences follow:

    * **Non-atomic on failure.** If ``os.open`` (or any step before ``os.replace``
      semantics could be introduced) fails after the ``unlink`` succeeds, the
      previous file is already gone. Callers that need the prior content to
      survive a failed write should snapshot it themselves before calling.
    * **New inode.** The resulting file has a different inode from any prior
      version at the same path, so hardlinks, `inotify` watchers on the old
      inode, or other consumers holding the old inode do not follow the new
      write.

    Arguments:
        file_name (str): Name or path of the file to be created.
        content (str): Text content to write into the file.
        logger (logging.Logger): Logger object for logging errors if file creation
            fails.
        base_dir (str, optional): Base directory to restrict writes to. When provided,
            file_name is resolved relative to base_dir and a ValueError is raised if the
            resolved path escapes base_dir (path traversal guard).

    Returns:
        None
    """
    if base_dir is not None:
        file_name = _resolve_within_base_dir(file_name, base_dir)

    try:
        # Best-effort remove any pre-existing (potentially loose) inode. If a
        # concurrent reader is already holding the old inode's read fd we cannot
        # sever that fd, but subsequent opens will go to the new inode we create
        # below with tight permissions.
        try:
            os.unlink(file_name)
        except FileNotFoundError:
            pass

        fd = _open_secure_fd(file_name)
        try:
            stream = os.fdopen(fd, "w", encoding="utf-8")
        except Exception:
            os.close(fd)
            raise
        with stream as f:
            f.write(content)
    except OSError as exc:
        logger.error("Failed to create file '%s': %s", file_name, exc)
        raise
