"""HTTP session and authentication for the GitHub Actions integrations."""

import logging

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

import secrets_safe_library
from secrets_safe_library import authentication, utils
from secrets_safe_library.integrations.github_actions.common_utils import common

DEFAULT_RETRY_STATUS_CODES = (400, 408, 500, 502, 503, 504)
DEFAULT_TIMEOUT_SECONDS = 30


def create_session(
    retry_status_codes: tuple[int, ...] | list[int] = DEFAULT_RETRY_STATUS_CODES,
) -> requests.Session:
    """
    Create a requests session that retries failed GET and POST requests.

    The retry policy is 3 retries with a 0.2 s backoff factor, on the given
    status codes. Pass a list without 400 when the caller must see a 400
    response itself: when 400 is retried, the last 400 raises a generic
    RetryError instead of being returned.

    Arguments:
        retry_status_codes (tuple[int, ...] | list[int]): Status codes to retry.

    Returns:
        requests.Session: The session. Close it when done, e.g. use it as a
        context manager.
    """

    retry_strategy = Retry(
        total=3,
        backoff_factor=0.2,
        status_forcelist=list(retry_status_codes),
        allowed_methods=["GET", "POST"],
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session = requests.Session()
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session


def authenticate(
    session: requests.Session,
    logger: logging.Logger,
    *,
    api_url: str | None,
    verify_ca: bool = True,
    api_key: str | None = None,
    client_id: str | None = None,
    client_secret: str | None = None,
    certificate: str = "",
    certificate_key: str = "",
    api_version: str | None = None,
    timeout_connection: int = DEFAULT_TIMEOUT_SECONDS,
    timeout_request: int = DEFAULT_TIMEOUT_SECONDS,
) -> authentication.Authentication:
    """
    Sign in to the API and fail the step when the credentials are rejected.

    Uses API key authentication when api_key is set (optionally with a client
    certificate), or OAuth client credentials otherwise. Authentication applies
    verify_ca to the session.

    Arguments:
        session (requests.Session): Session used for every API call.
        logger (logging.Logger): Logger object for logging.
        api_url (str | None): API base URL.
        verify_ca (bool): Result of parse_verify_ca; True or False only.
        api_key (str | None): API key; when empty, client credentials are used.
        client_id (str | None): OAuth client ID.
        client_secret (str | None): OAuth client secret.
        certificate (str): Client certificate (PEM) content, or "".
        certificate_key (str): Client certificate private key (PEM), or "".
        api_version (str | None): API version; when empty, the library default
            is used.
        timeout_connection (int): Connection timeout in seconds.
        timeout_request (int): Request timeout in seconds.

    Returns:
        authentication.Authentication: Authenticated client. Call
        sign_app_out() on it when done.
    """

    prepared_certificate, prepared_certificate_key = utils.prepare_certificate_info(
        certificate, certificate_key
    )

    auth_config = {
        "req": session,
        "timeout_connection": timeout_connection,
        "timeout_request": timeout_request,
        "api_url": api_url,
        "certificate": prepared_certificate,
        "certificate_key": prepared_certificate_key,
        "verify_ca": verify_ca,
        "logger": logger,
    }

    if api_version:
        auth_config["api_version"] = api_version

    if api_key:
        auth_config["api_key"] = api_key
    else:
        auth_config["client_id"] = client_id
        auth_config["client_secret"] = client_secret

    authentication_obj = authentication.Authentication(**auth_config)
    get_api_access_response = authentication_obj.get_api_access()

    utils.print_log(
        logger,
        f"{secrets_safe_library.__library_name__} "
        f"version: {secrets_safe_library.__version__}",
        logging.DEBUG,
    )

    if get_api_access_response.status_code != 200:
        common.show_error(
            f"Please check credentials, error {get_api_access_response.text}",
            logger,
        )

    return authentication_obj
