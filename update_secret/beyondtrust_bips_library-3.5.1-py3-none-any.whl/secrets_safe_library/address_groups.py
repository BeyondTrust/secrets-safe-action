"""
Address groups module, all the logic to manage address groups from BeyondInsight API
"""

import logging

from cerberus import Validator

from secrets_safe_library import exceptions, utils
from secrets_safe_library.authentication import Authentication
from secrets_safe_library.core import APIObject
from secrets_safe_library.mixins import DeleteByIdMixin, ListMixin


class AddressGroup(APIObject, DeleteByIdMixin, ListMixin):

    def __init__(self, authentication: Authentication, logger: logging.Logger = None):
        super().__init__(authentication, logger, endpoint="/addressgroups")

        # Schema rules used for validations
        self._schema = {
            "name": {"type": "string", "maxlength": 256, "nullable": False},
        }
        self._validator = Validator(self._schema)

        # Schema rules used for address validations
        self._address_schema = {
            "type": {
                "type": "string",
                "allowed": ["single", "range", "cidr", "name"],
                "nullable": False,
                "required": True,
            },
            "value": {
                "type": "string",
                "maxlength": 255,
                "nullable": False,
                "required": True,
            },
            "omit": {"type": "boolean", "nullable": True},
            "policy_id": {"type": "integer", "nullable": True},
        }
        self._address_validator = Validator(self._address_schema)

    def get_address_group_by_id(self, address_group_id: int) -> dict:
        """
        Find an address group by ID.

        API: GET AddressGroups/{id}

        Args:
            address_group_id (int): The address group ID.

        Returns:
            dict: Address group object according requested API version.
        """

        endpoint = f"{self.endpoint}/{address_group_id}"

        utils.print_log(
            self._logger,
            "Calling get_address_group_by_id endpoint",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)

        return response.json()

    def get_address_group_by_name(self, address_group_name: str) -> dict:
        """
        Returns an address group by name.

        API: GET AddressGroups/?name={name}

        Args:
            address_group_name (str): Name of the address group.

        Returns:
            dict: Address group.
        """

        endpoint = f"{self.endpoint}?name={address_group_name}"

        utils.print_log(
            self._logger,
            "Calling get_address_group_by_name endpoint",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)

        return response.json()

    def create_address_group(self, name: str) -> dict:
        """
        Creates a new address group.

        API: POST AddressGroups

        Args:
            name (str): Name of the address group.

        Returns:
            dict: Created address group object.
        """

        attributes = {"name": name}

        if not self._validator.validate(attributes, update=True):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        payload = {
            "Name": name,
        }

        utils.print_log(
            self._logger,
            f"Calling create_address_group endpoint: {self.endpoint}",
            logging.DEBUG,
        )
        response = self._run_post_request(self.endpoint, payload)

        return response.json()

    def update_address_group(self, address_group_id: int, name: str) -> dict:
        """
        Updates an address group by ID.

        API: PUT AddressGroups/{id}

        Args:
            address_group_id (int): The address group ID.
            name (str): Name of the address group.

        Returns:
            dict: Updated address group object.
        """

        attributes = {"name": name}

        if not self._validator.validate(attributes, update=True):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        payload = {
            "Name": name,
        }

        endpoint = f"{self.endpoint}/{address_group_id}"

        utils.print_log(
            self._logger,
            "Calling update_address_group endpoint",
            logging.DEBUG,
        )
        response = self._run_put_request(endpoint, payload)

        return response.json()

    def list_by_organization(self, organization_id: str) -> list:
        """
        Gets address groups for a given Organization ID.

        API: GET Organizations/{orgID}/AddressGroups

        Args:
            organization_id (str): The Organization GUID.

        Returns:
            list: Address groups belonging to the organization.
        """
        endpoint = f"/organizations/{organization_id}/addressgroups"

        utils.print_log(
            self._logger,
            f"Calling list_by_organization endpoint: {endpoint}",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)

        return response.json()

    def list_addresses(self, address_group_id: int) -> list:
        """
        Lists the addresses in an address group.

        API: GET AddressGroups/{addressGroupId}/Addresses

        Args:
            address_group_id (int): The address group ID.

        Returns:
            list: Addresses in the address group.
        """
        endpoint = f"{self.endpoint}/{address_group_id}/addresses"

        utils.print_log(
            self._logger,
            f"Calling list_addresses endpoint: {endpoint}",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)

        return response.json()

    def create_address(
        self,
        address_group_id: int,
        address_type: str,
        value: str,
        omit: bool = False,
        policy_id: int = None,
    ) -> dict:
        """
        Adds an address to an address group.

        API: POST AddressGroups/{id}/Addresses

        Args:
            address_group_id (int): The address group ID.
            address_type (str): Address type, one of "single", "range", "cidr" or
                "name".
            value (str): The address value (max 255 chars); format depends on the
                address type.
            omit (bool, optional): Whether to omit/exclude this address. Defaults to
                False.
            policy_id (int, optional): Obsolete, kept for backwards compatibility.

        Returns:
            dict: Created address object.
        """

        attributes = {
            "type": address_type,
            "value": value,
            "omit": omit,
            "policy_id": policy_id,
        }

        if not self._address_validator.validate(attributes):
            raise exceptions.OptionsError(
                f"Please check: {self._address_validator.errors}"
            )

        payload = {
            "Type": address_type,
            "Value": value,
            "Omit": omit,
        }
        if policy_id is not None:
            payload["PolicyID"] = policy_id

        endpoint = f"{self.endpoint}/{address_group_id}/addresses"

        utils.print_log(
            self._logger,
            f"Calling create_address endpoint: {endpoint}",
            logging.DEBUG,
        )
        response = self._run_post_request(endpoint, payload)

        return response.json()

    def delete_all_addresses(
        self, address_group_id: int, expected_status_code: int = 200
    ) -> None:
        """
        Removes all addresses from an address group.

        API: DELETE AddressGroups/{addressGroupId}/Addresses

        Args:
            address_group_id (int): The address group ID.
            expected_status_code (int, optional): Expected status code. Defaults to
                200.
        """
        endpoint = f"{self.endpoint}/{address_group_id}/addresses"

        utils.print_log(
            self._logger,
            f"Calling delete_all_addresses endpoint: {endpoint}",
            logging.DEBUG,
        )
        self._run_delete_request(endpoint, expected_status_code=expected_status_code)
