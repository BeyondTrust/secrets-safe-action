__version__ = "1.0.2"
__library_name__ = "Secret Safe Library"