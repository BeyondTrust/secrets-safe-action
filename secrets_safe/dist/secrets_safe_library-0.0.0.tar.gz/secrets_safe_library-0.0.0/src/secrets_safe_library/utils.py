"""Utils module"""

import logging

def print_log(logger, log_message, level):
    """
    Print a log message
    Arguments:
        Logger
        Log level
        Log message
    Returns:
    """
    if logger:
        if level == logging.DEBUG:
            logger.debug(log_message)
        elif level == logging.INFO:
            logger.info(log_message)
        elif level == logging.ERROR:
            logger.error(log_message)
        elif level == logging.WARN:
            logger.warning(log_message)