# Password Safe API integration
[![License](https://img.shields.io/badge/license-GPL%20v3.0-brightgreen.svg)](LICENSE)

Password Safe API integration written in Python, Abstract complexity of managing secrets with the API

## Python version compatibility
  
This library is compatible with Python >= v3.11.

## Install Package

```sh
# PyPI
pip install secrets-safe-library
```
## Arguments

### Retrieve Secrets
- api_url:
    - description: BeyondTrust Password Safe API URL.
    - type: string
    - required: True
- client_id:
    - description: API OAuth Client ID.
    - type: string
    - required: True
- client_secret:
    - description: API OAuth Client Secret.
    - type: string
    - required: True
- secret_list:
    - description: List of secrets (path/title,path/title) or managed accounts (ms/ma,ms/ma) to be retrieved, separated by a comma.
    - type: string
    - required: True
- certificate_path:
    - description: Password Safe API pfx Certificate Path. For use when authenticating using a Client Certificate.
    - type: string
    - required: False
- certificate_password:
    - description: Password Safe API pfx Certificate Password. For use when authenticating using a Client Certificate.
    - type: string
    - required: False
- verify_ca:
    - description: Indicates whether to verify the certificate authority on the Secrets Safe instance.
    - type: boolean 
    - default: True
    - required: False

## Methods
- get_secrets(self, paths)
	- Invoked for Managed Account or Secrets Safe secrets.
	- Returns a list of secrets in the requested order.
- get_secret(self, path)
	- Invoked for Managed Account or Secrets Safe secrets.
	- Returns the requested secret.

## Example of usage

We strongly recommend you to use a virtual environment and install dependences from requirements.txt file.

```sh
pip install -r ~/requirements.txt
```

script example using library:
```python
import  os
import  logging
from  secrets_safe_package  import  secrets_safe, authentication, utils

env  =  os.environ
LOGGER_NAME  =  "custom_logger"

logging.basicConfig(format  =  '%(asctime)-5s  %(name)-15s  %(levelname)-8s  %(message)s',

level  =  logging.DEBUG)
logger  =  logging.getLogger(LOGGER_NAME)

def  main():
	try:
		authentication_obj  =  authentication.Authentication(
			"https://example.com:443/BeyondTrust/api/public/v3",
		=*************************,
		=*************************,
		"/home/user/docker-container-action/using-pacakge/j2310.pfx",
		=*************************,
		True)

		get_api_access_response  =  authentication_obj.get_api_access()

		if  get_api_access_response.status_code ==  200:
			secrets_safe_obj  =  secrets_safe.SecretsSafe(authentication_obj, logger)

				get_secrets_response  =  secrets_safe_obj.get_secrets("oauthgrp/text2,oauthgrp/credential8")
				utils.print_log(logger, f"=> Retrive secrets: {get_secrets_response}", logging.DEBUG)
		else:
			print(f"Please check credentials, error {get_api_access_response.text}")

	except  Exception  as  e:
		utils.print_log(logger, f"Error: {e}", logging.ERROR)

# calling main method
main()
```