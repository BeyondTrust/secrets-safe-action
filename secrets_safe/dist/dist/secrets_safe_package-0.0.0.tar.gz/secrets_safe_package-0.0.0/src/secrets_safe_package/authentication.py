"""Authentication Module, all the logic to authenticate in PS API"""

import requests
import contextlib
import tempfile
import OpenSSL.crypto
import json
import logging

from retry_requests import retry
from secrets_safe_package import utils, exceptions

req = retry(requests.Session(), retries=3, backoff_factor=0.2)

class Authentication:
    
    _api_url = None
    _client_id = None
    _client_secret = None
    _verify_ca = True
    _token = None
    _certificate_path = None
    _certificate_password = None
    _sig_app_in_url = None
    _api_token = None
    _req = None
    _logger = None
    
    def __init__(self, api_url, client_id, client_secret, certificate_path, certificate_password, verify_ca=True, logger=None):
        
        self._api_url = api_url
        self._client_id = client_id
        self._client_secret = client_secret
        self._verify_ca = verify_ca
        self._sig_app_in_url = f"{self._api_url}/Auth/SignAppIn/"
        self._req = req
        self._certificate_path = certificate_path
        self._certificate_password = certificate_password
        self._logger = logger
        
        self.validate_input("api_url", self._api_url)
        self.validate_input("client_id", self._client_id)
        self.validate_input("client_secret", self._client_secret)
        
    def oauth(self):
        """
        Get API Token
        Arguments:
            Client Id
            Secret
        Returns:
            Token
        """

        endpoint_url = self._api_url + "/Auth/connect/token"
        header = {'Content-Type' : 'application/x-www-form-urlencoded'}
        auth_info = {
            'client_id' : self._client_id,
            'client_secret' : self._client_secret,
            'grant_type' : 'client_credentials'
        }

        response = requests.post(endpoint_url, auth_info, header, verify=self._verify_ca)
        return response
    
    def sign_app_in(self):
        """
        Sign in to Secret safe API
        Arguments:
        Returns:
            logged user
        """

        utils.print_log(self._logger, f"Calling sign_app_in endpoint: {self._api_url}", logging.DEBUG)

        if self._certificate_path:
            with self.pfx_to_pem() as cert:
                return self.send_post_sign_app_in(cert)

        else:
            utils.print_log(self._logger, "Certificate was not configured", logging.DEBUG)
            return self.send_post_sign_app_in(None)

    def get_api_access(self):
        """
        Get API Access
        Arguments:
        Returns:
            Result of sign_app_in call
        """

        oauth_response = self.oauth()

        if oauth_response.status_code != 200:
            raise exceptions.AuthenticationFailure(f"Error getting token, message: {oauth_response.text}, statuscode: {oauth_response.status_code}")
                        
        token_object=json.loads(oauth_response.text)
        self._api_token = token_object['access_token']
        return self.sign_app_in()

    def sign_app_out(self):
        """
        Sign out to Secret safe API
        Arguments:
        Returns:
            Status of the action
        """
        url = f"{self._api_url}/Auth/Signout"
        utils.print_log(self._logger, f"Calling sign_app_out endpoint: {url}", logging.DEBUG)
        
        # Connection : close - tells the connection pool to close the connection.
        response = self._authentication._req.post(url, headers={'Connection':'close'})
        if response.status_code == 200:
            return True
        
        return False

    def send_post_sign_app_in(self, cert):
        """
        Send Post request to Sign app in service
        Arguments:
        Returns:
            Service URL
            Certificate
        """
            
        headers = {'Authorization': f'Bearer {self._api_token}'}
        response = self._req.post(self._sig_app_in_url, headers=headers, cert=cert)
        return response

    @contextlib.contextmanager
    def pfx_to_pem(self):
        """
        Decrypts the .pfx file to be used with requests
        Arguments:
            PFX path
            PFX Password
        Returns:
            PEM file name
        """

        try:
            with tempfile.NamedTemporaryFile(suffix='.pem') as t_pem:
                f_pem = open(t_pem.name, 'wb')
                pfx = None
                #pfx = open(self._certificate_path, 'rb').read()
                with open(self._certificate_path, 'rb') as f:
                    pfx = f.read()
                p12 = OpenSSL.crypto.load_pkcs12(pfx, self._certificate_password)
                f_pem.write(OpenSSL.crypto.dump_privatekey(OpenSSL.crypto.FILETYPE_PEM, p12.get_privatekey()))
                f_pem.write(OpenSSL.crypto.dump_certificate(OpenSSL.crypto.FILETYPE_PEM, p12.get_certificate()))
                ca = p12.get_ca_certificates()
                if ca is not None:
                    for cert in ca:
                        f_pem.write(OpenSSL.crypto.dump_certificate(OpenSSL.crypto.FILETYPE_PEM, cert))
                f_pem.close()
                yield t_pem.name
                
        except FileNotFoundError as e:
            raise FileNotFoundError(f"Certificate not found: {e}")
        except Exception as e:
            raise exceptions.AuthenticationFailure(f"Missing certificate password or incorrect certificate password: {e}")


    def validate_input(self, parameter_name, parameter_value):
        """
        Validate input
        Arguments:
            Parameter name
            Parameter Value
        Returns:
        """
        if not parameter_value:
            raise exceptions.OptionsError(f"{parameter_name} parameter is missing")
