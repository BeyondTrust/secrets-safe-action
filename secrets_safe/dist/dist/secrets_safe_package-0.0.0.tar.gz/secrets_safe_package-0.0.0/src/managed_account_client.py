import os
import logging
from secrets_safe_package import managed_account, authentication, utils

env = os.environ

PASSWORD_SAFE_CLIENT_ID = env["PASSWORD_SAFE_CLIENT_ID"] if 'PASSWORD_SAFE_CLIENT_ID' in env else None
PASSWORD_SAFE_CLIENT_SECRET = env["PASSWORD_SAFE_CLIENT_SECRET"] if 'PASSWORD_SAFE_CLIENT_SECRET' in env else None
PASSWORD_SAFE_API_URL = env["PASSWORD_SAFE_API_URL"] if 'PASSWORD_SAFE_API_URL' in env else None
VERIFY_CA = True if 'VERIFY_CA' in env and env['VERIFY_CA'].lower() == 'true' else False
MANAGED_ACCOUNT = env['MANAGED_ACCOUNT'].strip() if 'MANAGED_ACCOUNT' in env else None
MANAGED_ACCOUNT_LIST = env['MANAGED_ACCOUNT_LIST'].strip().split(",") if 'MANAGED_ACCOUNT_LIST' in env and env['MANAGED_ACCOUNT_LIST'].strip() != "" else None

LOGGER_NAME = "custom_logger"

logging.basicConfig(
    format = '%(asctime)-5s %(name)-15s %(levelname)-8s %(message)s', 
    level  = logging.DEBUG
)

logger = logging.getLogger(LOGGER_NAME)

CERTIFICATE_PATH = None
if 'CERTIFICATE_PATH' in env:
    if len(env['CERTIFICATE_PATH']) > 0:
        CERTIFICATE_PATH = env['CERTIFICATE_PATH']

CERTIFICATE_PASSWORD = env['CERTIFICATE_PASSWORD'] if 'CERTIFICATE_PASSWORD' in env and CERTIFICATE_PATH else ""

def main():
    try:
        authentication_obj = authentication.Authentication(PASSWORD_SAFE_API_URL, 
                                                    PASSWORD_SAFE_CLIENT_ID, 
                                                    PASSWORD_SAFE_CLIENT_SECRET,
                                                    CERTIFICATE_PATH,
                                                    CERTIFICATE_PASSWORD,
                                                    VERIFY_CA,
                                                    logger)
        
        
        get_api_access_response = authentication_obj.get_api_access()
        
        if get_api_access_response.status_code == 200:
                managed_account_obj = managed_account.ManagedAccount(authentication=authentication_obj, logger=logger, separator="*")
                if MANAGED_ACCOUNT or MANAGED_ACCOUNT_LIST:
                    if MANAGED_ACCOUNT:
                        get_secret_response = managed_account_obj.get_secret(MANAGED_ACCOUNT)
                        utils.print_log(logger, f"=> Retrive managed account: {get_secret_response}", logging.DEBUG)
                    if MANAGED_ACCOUNT_LIST:
                        get_secrets_response = managed_account_obj.get_secrets(MANAGED_ACCOUNT_LIST)
                        utils.print_log(logger, f"=> Retrive managed accounts: {get_secrets_response}", logging.DEBUG)
                else:
                    utils.print_log(logger, f"Nothing to do, MANAGED_ACCOUNT and MANAGED_ACCOUNT_LIST parameters are empty!", logging.ERROR)
        else:
            utils.print_log(logger, f"Please check credentials, error {get_api_access_response.text}", logging.ERROR)
    except Exception as e:
        utils.print_log(logger, e, logging.ERROR)

# calling main method
main()
